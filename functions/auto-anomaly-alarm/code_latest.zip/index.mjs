import { JWT } from 'google-auth-library';
import mysql from 'mysql2/promise';
import { createRequire } from 'module';

const require = createRequire(import.meta.url);
const serviceAccount = require('./firebase-sdk-key.json');

async function getAccessToken() {
  const jwtClient = new JWT({
    email: serviceAccount.client_email,
    key: serviceAccount.private_key,
    scopes: ['https://www.googleapis.com/auth/firebase.messaging'],
  });

  const accessToken = await jwtClient.authorize();
  return accessToken.access_token;
}

async function sendNotification(token, title, body) {
  const accessToken = await getAccessToken();

  const message = {
    message: {
      token,
      notification: { title, body },
      android: { priority: 'high' },
    },
  };

  const response = await fetch(
    'https://fcm.googleapis.com/v1/projects/dayinbloom-4dde1/messages:send',
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(message),
    }
  );

  const data = await response.json();
  console.log('Status:', response.status);
  console.log('Response:', data);

  return {
    success: response.ok ?? false,
    response: data,
  };
}

export const handler = async (event) => {
  let connection;

  try {
    const detail = event.detail;

    const encodedId = detail.fitbit_user_id;
    const detectedAtUTC = new Date(detail.date);
    const formattedDateKST = new Intl.DateTimeFormat('ko-KR', {
      timeZone: 'Asia/Seoul',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: false,
    }).format(detectedAtUTC);
    
    const messageBody = `${detail.detail || '심박수 이상이 감지되었습니다.'}\n[감지 시각: ${formattedDateKST}]`;
    
    console.log('encodedId:', encodedId);
    console.log('messageBody:', messageBody);

    connection = await mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
    });  

    const [[user]] = await connection.execute(
      `SELECT id, role, status FROM users WHERE encodedId = ?`,
      [encodedId]
    );
    
    if (!user || user.role !== 'senior' || user.status !== 'active') {
      console.log(`User not found or inactive for encodedId: ${encodedId}`);
      return {
        statusCode: 404,
        body: JSON.stringify({ message: 'User not found or inactive' }),
      };
    }    
    
    const [[activeToken]] = await connection.execute(
      `SELECT fcm_token FROM device_tokens WHERE user_id = ? AND is_active = TRUE`,
      [user.id]
    );
    console.log('Active token:', activeToken);
    
    const [[alertSetting]] = await connection.execute(
      `SELECT * FROM user_alerts WHERE user_id = ? AND alert_type = 'anomaly_alert' AND is_enabled = TRUE`,
      [user.id]
    );
    console.log('Alert setting:', alertSetting);

    const [userRows] = await connection.execute(
      `
      SELECT u.id
      FROM users u
      JOIN device_tokens dt ON dt.user_id = u.id AND dt.is_active = TRUE
      JOIN user_alerts ua ON ua.user_id = u.id AND ua.alert_type = 'anomaly_alert' AND ua.is_enabled = TRUE
      WHERE u.encodedId = ? AND u.role = 'senior' AND u.status = 'active'
      LIMIT 1      
      `,
      [encodedId]
    );  

    if (userRows.length === 0) {
      console.log(`User not found for encodedId: ${encodedId}`);
      return {
        statusCode: 404,
        body: JSON.stringify({ message: 'User not found' }),
      };
    }

    const userId = userRows[0].id;

    const [tokenRows] = await connection.execute(
      'SELECT fcm_token FROM device_tokens WHERE user_id = ? AND is_active = TRUE',
      [userId]
    );

    if (tokenRows.length === 0) {
      console.log('No active token found for user:', userId);
      return {
        statusCode: 404,
        body: JSON.stringify({ message: 'No active token found' }),
      };
    }

    const fcmToken = tokenRows[0].fcm_token;
    const title = '꽃이 되는 하루';

    const { success = false, response } = await sendNotification(fcmToken, title, messageBody);

    await connection.execute(
      `INSERT INTO notifications (user_id, notification_type, message, triggered_by, sent_at, is_push_sent)
       VALUES (?, ?, ?, ?, NOW(), ?)`,
      [userId, 'anomaly_alert', messageBody, 'system', success]
    );

    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'Notification sent successfully', pushSent: success }),
    };
  } catch (error) {
    console.error('Error sending notification:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Failed to send notification' }),
    };
  } finally {
    if (connection) {
      await connection.end();
    }
  }
};
