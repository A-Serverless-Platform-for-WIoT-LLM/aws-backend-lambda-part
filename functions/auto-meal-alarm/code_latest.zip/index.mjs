import { JWT } from 'google-auth-library';
import mysql from 'mysql2/promise';
import { createRequire } from 'module';

const require = createRequire(import.meta.url);
const serviceAccount = require('./firebase-sdk-key.json');

async function getAccessToken() {
  const jwtClient = new JWT({
    email: serviceAccount.client_email,
    key: serviceAccount.private_key,
    scopes: ['https://www.googleapis.com/auth/firebase.messaging'],
  });

  const accessToken = await jwtClient.authorize();
  return accessToken.access_token;
}

async function sendNotification(token, title, body) {
  const accessToken = await getAccessToken();

  const message = {
    message: {
      token,
      notification: { title, body },
      android: { priority: 'high' },
    },
  };

  const response = await fetch(
    'https://fcm.googleapis.com/v1/projects/dayinbloom-4dde1/messages:send',
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(message),
    }
  );

  const data = await response.json();
  console.log('FCM Response:', response.status, data);
  console.log(data);

  return { success: response.ok, response: data };
}

export const handler = async (event) => {
  let connection;

  try {
    connection = await mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
    });

    const { fitbit_user_id, meal_type } = event.detail || {};

    if (!fitbit_user_id || !meal_type) {
      console.warn('Missing fitbit_user_id or meal_type in event');
      return {
        statusCode: 400,
        body: JSON.stringify({ message: 'Missing fitbit_user_id or meal_type' }),
      };
    }

    const [[user]] = await connection.execute(
      `SELECT id FROM users WHERE encodedId = ? AND role = 'senior' AND status = 'active'`,
      [fitbit_user_id]
    );

    if (!user) {
      console.log(`No active senior with encodedId: ${fitbit_user_id}`);
      return {
        statusCode: 404,
        body: JSON.stringify({ message: 'User not found or inactive' }),
      };
    }

    const userId = user.id;

    const [[alertSetting]] = await connection.execute(
      `SELECT * FROM user_alerts WHERE user_id = ? AND alert_type = 'meal_reminder' AND is_enabled = TRUE`,
      [userId]
    );

    if (!alertSetting) {
      console.log(`Meal reminder not enabled for user ${userId}`);
      return {
        statusCode: 200,
        body: JSON.stringify({ message: 'Meal reminder disabled for this user' }),
      };
    }

    const [tokens] = await connection.execute(
      'SELECT fcm_token FROM device_tokens WHERE user_id = ? AND is_active = TRUE',
      [userId]
    );

    if (tokens.length === 0) {
      console.warn(`No active token found for user ${userId}`);
      return {
        statusCode: 200,
        body: JSON.stringify({ message: 'No active device token' }),
      };
    }

    const fcmToken = tokens[0].fcm_token;
    const title = '꽃이 되는 하루';
    const type = (meal_type || '').trim().toLowerCase();
    let body = '';

    if (type === 'breakfast') {
      body = '아침밥은 하루의 에너지! 꼭 챙겨드세요^^';
    } else if (type === 'lunch') {
      body = '점심에는 맛있는 메뉴를 찾아서 드셔보세요!';
    } else if (type === 'dinner') {
      body = '저녁은 가볍게, 영양소는 골고루 챙겨드세요';
    } else {
      console.warn(`Unknown meal_type: '${meal_type}'`);
      return {
        statusCode: 400,
        body: JSON.stringify({ message: 'Invalid meal_type value' }),
      };
    }

    const { success } = await sendNotification(fcmToken, title, body);

    await connection.execute(
      `INSERT INTO notifications (user_id, notification_type, message, triggered_by, sent_at, is_push_sent)
       VALUES (?, ?, ?, ?, NOW(), ?)`,
      [userId, 'meal_reminder', body, 'system', success]
    );

    return {
      statusCode: 200,
      body: JSON.stringify({
        message: 'Notification sent',
        userId,
        meal_type: type,
        pushSent: success,
      }),
    };
  } catch (error) {
    console.error('Error sending meal reminder notification:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Internal error occurred' }),
    };
  } finally {
    if (connection) await connection.end();
  }
};
