import mysql from 'mysql2/promise';

export const handler = async (event) => {
  let connection;

  try {
    const body = JSON.parse(event.body || '{}');
    const {
      encodedId,
      date,
      question,
      multiple_choice_response,
      text_response,
      gpt_qna_analysis
    } = body;

    if (!encodedId || !date || !question || !multiple_choice_response || !gpt_qna_analysis) {
      return buildResponse(400, { error: '필수 항목이 누락되었습니다.' });
    }

    connection = await createDbConnection();

    const [[userRow]] = await connection.execute(
      'SELECT id FROM users WHERE encodedId = ?',
      [encodedId]
    );

    if (!userRow) {
      return buildResponse(404, { error: '해당 사용자를 찾을 수 없습니다.' });
    }

    const userId = userRow.id;
    const timestamp = new Date();

    const [result] = await connection.execute(`
      INSERT INTO qna_info (
        user_id, timestamp, date, question,
        multiple_choice_response, text_response, gpt_qna_analysis
      ) VALUES (?, ?, ?, ?, ?, ?, ?)
      ON DUPLICATE KEY UPDATE
        timestamp = VALUES(timestamp),
        question = VALUES(question),
        multiple_choice_response = VALUES(multiple_choice_response),
        text_response = VALUES(text_response),
        gpt_qna_analysis = VALUES(gpt_qna_analysis)
    `, [
      userId,
      timestamp,
      date,
      JSON.stringify(question),
      JSON.stringify(multiple_choice_response),
      text_response ? JSON.stringify(text_response) : null,
      gpt_qna_analysis
    ]);

    return buildResponse(200, { message: 'QnA 분석 결과 저장 완료' });
  } catch (error) {
    console.error('[Lambda error]', error);
    return buildResponse(500, { error: '서버 오류', detail: error.message });
  } finally {
    if (connection) await connection.end();
  }
};

async function createDbConnection() {
  return await mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    charset: 'utf8mb4'
  });
}

function buildResponse(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json; charset=utf-8' },
    body: JSON.stringify(body)
  };
}
