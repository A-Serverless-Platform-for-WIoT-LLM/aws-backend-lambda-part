import mysql from 'mysql2/promise';

export const handler = async (event) => {
  let connection;
  try {
    const encodedId = event.queryStringParameters?.encodedId;
    if (!encodedId) {
      return buildResponse(400, { error: 'Missing encodedId' });
    }

    connection = await mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
      charset: 'utf8mb4',
    });

    const [userRows] = await connection.execute(
      'SELECT id FROM users WHERE encodedId = ?',
      [encodedId]
    );
    if (userRows.length === 0) {
      return buildResponse(404, { error: 'User not found' });
    }

    const userId = userRows[0].id;

    const [missionRows] = await connection.execute(
      'SELECT date, marker_type FROM daily_missions WHERE user_id = ?',
      [userId]
    );
 
    const [reportRows] = await connection.execute(
      `SELECT report_date 
       FROM daily_health_reports 
       WHERE user_id = ? AND report_status = 'completed'`,
      [userId]
    );
    
    const reportDates = new Set(reportRows.map(r => r.report_date.toISOString().split('T')[0]));
    
    const enriched = missionRows.map(row => {
      const date = row.date.toISOString().split('T')[0];
      return {
        date,
        marker_type: row.marker_type,
        has_report: reportDates.has(date),
      };
    });
    
    return buildResponse(200, enriched);
    
  } catch (error) {
    console.error('Lambda error:', error);
    return buildResponse(500, { error: 'Internal Server Error', message: error.message });
  } finally {
    if (connection) await connection.end();
  }
};

function buildResponse(statusCode, body) {
  return {
    statusCode,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Access-Control-Allow-Origin': '*',
    },
    body: JSON.stringify(body),
  };
}
