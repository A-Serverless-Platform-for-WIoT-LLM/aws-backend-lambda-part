import { JWT } from 'google-auth-library';
import mysql from 'mysql2/promise';
import { createRequire } from 'module';

const require = createRequire(import.meta.url);
const serviceAccount = require('./firebase-sdk-key.json');

async function getAccessToken() {
  const jwtClient = new JWT({
    email: serviceAccount.client_email,
    key: serviceAccount.private_key,
    scopes: ['https://www.googleapis.com/auth/firebase.messaging'],
  });

  const accessToken = await jwtClient.authorize();
  return accessToken.access_token;
}

async function sendNotification(token, title, body) {
  const accessToken = await getAccessToken();

  const message = {
    message: {
      token,
      notification: { title, body },
      android: { priority: 'high' },
    },
  };

  const response = await fetch(
    'https://fcm.googleapis.com/v1/projects/dayinbloom-4dde1/messages:send',
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(message),
    }
  );

  const data = await response.json();
  console.log('FCM Response:', response.status, data);

  return { success: response.ok, response: data };
}

export const handler = async (event) => {
  let connection;

  try {
    connection = await mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
    });

    const [users] = await connection.execute(
      `
      SELECT u.id
      FROM users u
      JOIN device_tokens dt ON dt.user_id = u.id AND dt.is_active = TRUE
      JOIN user_alerts ua ON ua.user_id = u.id AND ua.alert_type = 'morning_alert' AND ua.is_enabled = TRUE
      WHERE u.role = 'senior' AND u.status = 'active'
      `
    );

    if (users.length === 0) {
      console.log('No senior users found.');
      return { statusCode: 200, body: 'No users to notify' };
    }

    const title = '꽃이 되는 하루';
    const body = '좋은 아침이에요! 잠은 푹 주무셨나요?';
    const triggeredBy = 'system';
    const notificationType = 'morning_alert';

    const failedUsers = [];

    const results = await Promise.allSettled(
      users.map(async ({ id: userId }) => {
        try {
          const [tokens] = await connection.execute(
            'SELECT fcm_token FROM device_tokens WHERE user_id = ? AND is_active = TRUE',
            [userId]
          );

          if (tokens.length === 0) {
            console.log(`No active token for user ${userId}`);
            failedUsers.push(userId);
            return;
          }

          const fcmToken = tokens[0].fcm_token;

          const { success, response } = await sendNotification(fcmToken, title, body);

          console.log(`Notification to user ${userId} - Success: ${success}`);

          await connection.execute(
            `INSERT INTO notifications (user_id, notification_type, message, triggered_by, sent_at, is_push_sent)
             VALUES (?, ?, ?, ?, NOW(), ?)`,
            [userId, notificationType, body, triggeredBy, success]
          );

          if (!success) {
            failedUsers.push(userId);
          }
        } catch (err) {
          console.error(`Error processing user ${userId}:`, err);
          failedUsers.push(userId);
        }
      })
    );

    const successCount = results.length - failedUsers.length;
    const failCount = failedUsers.length;

    return {
      statusCode: 200,
      body: JSON.stringify({
        message: `Notifications attempted. Success: ${successCount}, Failed: ${failCount}`,
        failedUserIds: failedUsers,
      }),
    };
  } catch (error) {
    console.error('Error processing notifications:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Notification processing failed' }),
    };
  } finally {
    if (connection) {
      await connection.end();
    }
  }
};
