import mysql from 'mysql2/promise';

export const handler = async (event) => {
  let connection;

  try {
    const body = JSON.parse(event.body);

    const {
      username, height, weight,
      birth_date, gender, encodedId,
      role = 'senior', login_provider = 'fitbit'
    } = body;

    if (!username || !birth_date || !gender || !encodedId) {
      return buildResponse(400, { error: 'Missing required fields' });
    }

    connection = await createDbConnection();

    const heightMeters = parseFloat(height) / 100;
    const bmi = parseFloat(weight) / (heightMeters * heightMeters);

    const [result] = await connection.execute(`
      INSERT INTO users (
        username, height, weight, birth_date, gender, encodedId, BMI, role, login_provider, is_profile_complete
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, true)
      ON DUPLICATE KEY UPDATE
        username = VALUES(username),
        height = VALUES(height),
        weight = VALUES(weight),
        birth_date = VALUES(birth_date),
        gender = VALUES(gender),
        BMI = VALUES(BMI),
        role = VALUES(role),
        login_provider = VALUES(login_provider),
        is_profile_complete = true,
        updated_at = CURRENT_TIMESTAMP
    `, [username, height, weight, birth_date, gender, encodedId, bmi, role, login_provider]);

    const [userRows] = await connection.execute(
      'SELECT id FROM users WHERE encodedId = ?',
      [encodedId]
    );

    if (userRows.length === 0) {
      return buildResponse(500, { error: 'User insertion failed or user not found.' });
    }

    const userId = userRows[0].id;

    const alertTypes = [
      'meal_reminder',
      'report_ready',
      'morning_alert',
      'anomaly_alert',
      'sleep_alert',
      'exercise_alert'
    ];

    const alertInsertValues = alertTypes.map(type => `(${userId}, '${type}', TRUE)`).join(',');

    await connection.execute(`
      INSERT IGNORE INTO user_alerts (user_id, alert_type, is_enabled)
      VALUES ${alertInsertValues}
    `);

    return buildResponse(200, { message: 'User info and alerts saved successfully.' });
  } catch (error) {
    console.error('Lambda error:', error);
    return buildResponse(500, { error: 'Internal Server Error', detail: error.message });
  } finally {
    if (connection) await connection.end();
  }
};

async function createDbConnection() {
  return await mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    charset: 'utf8mb4',
  });
}

function buildResponse(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  };
}
