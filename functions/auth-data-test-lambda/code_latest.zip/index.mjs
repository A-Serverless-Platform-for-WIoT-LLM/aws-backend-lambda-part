import mysql from 'mysql2/promise';

export async function handler(event) {
  try {
    console.log("[전체 event 로그]:");
    console.log(JSON.stringify(event, null, 2));

    if (!event.body) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "요청 body가 없습니다." }),
      };
    }

    let data;
    try {
      data = JSON.parse(event.body);
    } catch (e) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "잘못된 JSON 형식입니다.", detail: e.message }),
      };
    }

    console.log("[받은 데이터]:");
    console.log(JSON.stringify(data, null, 2));

    const { fitbit_user_id, access_token, refresh_token } = data;

    if (!fitbit_user_id || !access_token || !refresh_token) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "필수 값 누락", detail: { fitbit_user_id, access_token, refresh_token } }),
      };
    }

    const connection = await mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
    });

    // 1. 먼저 업데이트 시도
    const [updateResult] = await connection.execute(`
      UPDATE users
      SET 
        access_token = ?, 
        refresh_token = ?, 
        updated_at = NOW()
      WHERE encodedId = ?
    `, [access_token, refresh_token, fitbit_user_id]);

    // 2. 업데이트 된 게 없으면 -> INSERT
    if (updateResult.affectedRows === 0) {
      const [insertResult] = await connection.execute(`
        INSERT INTO users (encodedId, access_token, refresh_token, login_provider, role, is_profile_complete)
        VALUES (?, ?, ?, 'fitbit', 'senior', false)
      `, [fitbit_user_id, access_token, refresh_token]);

      console.log("INSERT 결과:", insertResult);

      await connection.end();

      return {
        statusCode: 201,
        headers: { "Content-Type": "application/json; charset=utf-8" },
        body: JSON.stringify({ message: "신규 사용자 등록 및 토큰 저장 완료", user_id: insertResult.insertId }),
      };
    }

    await connection.end();

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json; charset=utf-8" },
      body: JSON.stringify({ message: "기존 사용자 토큰 업데이트 완료" }),
    };
  } catch (error) {
    console.error("[에러 발생]:", error);

    return {
      statusCode: 500,
      body: JSON.stringify({ error: "서버 오류 발생", message: error.message }),
    };
  }
}
