import mysql from 'mysql2/promise';

export const handler = async (event) => {
  let connection;

  try {
    const { encodedId } = parseRequestBody(event.body);

    connection = await createDbConnection();

    const [rows] = await connection.execute(
      `SELECT username, birth_date, gender, address, phone_number, height, weight,
              profile_image_url, profile_image_key, breakfast_time, lunch_time, dinner_time,
              guardian_code, doctor_code
         FROM users
        WHERE encodedId = ?`,
      [encodedId]
    );

    if (rows.length === 0) {
      return buildResponse(404, { error: 'User not found' });
    }

    return buildResponse(200, rows[0]);
  } catch (error) {
    console.error('Lambda error:', error);
    return buildResponse(500, { error: 'Internal Server Error', detail: error.message });
  } finally {
    if (connection) await connection.end();
  }
};

function parseRequestBody(body) {
  if (!body) throw new Error('Missing request body');
  const parsed = JSON.parse(body);
  if (!parsed.encodedId) throw new Error('Missing encodedId');
  return parsed;
}

async function createDbConnection() {
  return await mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    charset: 'utf8mb4',
  });
}

function buildResponse(statusCode, body) {
  return {
    statusCode,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
    },
    body: JSON.stringify(body),
  };
}
