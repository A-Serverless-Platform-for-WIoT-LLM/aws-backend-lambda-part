import mysql from 'mysql2/promise';

export const handler = async (event) => {
  let connection;

  try {
    const body = JSON.parse(event.body || '{}');
    const { encodedId } = body;

    if (!encodedId) {
      return buildResponse(400, { error: 'encodedId가 누락되었습니다.' });
    }

    connection = await mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
      charset: 'utf8mb4',
    });

    // 트랜잭션 시작
    await connection.beginTransaction();

    const [[user]] = await connection.execute(
      'SELECT id FROM users WHERE encodedId = ?',
      [encodedId]
    );

    if (!user) {
      return buildResponse(404, { message: '해당 encodedId를 가진 유저가 존재하지 않습니다.' });
    }

    const userId = user.id;

    // 자식 테이블 순서대로 삭제
    const deleteQueries = [
      'DELETE FROM comments WHERE report_id IN (SELECT id FROM daily_health_reports WHERE user_id = ?)',
      'DELETE FROM comments WHERE author_id = ?',
      'DELETE FROM health_reports_pdf WHERE user_id = ?',
      'DELETE FROM s3_bucket WHERE related_report_id IN (SELECT id FROM daily_health_reports WHERE user_id = ?)',
      'DELETE FROM health_analyzer WHERE user_id = ?',
      'DELETE FROM notifications WHERE user_id = ?',
      'DELETE FROM qna_info WHERE user_id = ?',
      'DELETE FROM fitbit_sleep_data WHERE user_id = ?',
      'DELETE FROM fitbit_average_history WHERE user_id = ?',
      'DELETE FROM fitbit_average WHERE user_id = ?',
      'DELETE FROM fitbit_health_metrics WHERE user_id = ?',
      'DELETE FROM fitbit_activity_summary WHERE user_id = ?',
      'DELETE FROM fitbit_activity_data WHERE user_id = ?',
      'DELETE FROM device_tokens WHERE user_id = ?',
      'DELETE FROM daily_health_reports WHERE user_id = ?',
      'DELETE FROM daily_missions WHERE user_id = ?',
      'DELETE FROM fitbit_device WHERE user_id = ?',
      'DELETE FROM guardian_doctor_links WHERE user_id = ? OR senior_id = ?',
      'DELETE FROM user_alerts WHERE user_id = ?',
    ];    

    for (const query of deleteQueries) {
      await connection.execute(query, query.includes('OR') ? [userId, userId] : [userId]);
    }

    // 최종적으로 유저 삭제
    const [deleteUserResult] = await connection.execute(
      'DELETE FROM users WHERE id = ?',
      [userId]
    );

    await connection.commit();

    return buildResponse(200, {
      message: '유저 및 관련 데이터가 성공적으로 삭제되었습니다.',
      deletedUserId: userId,
      deletedRows: deleteUserResult.affectedRows,
    });
  } catch (error) {
    console.error('[Lambda error]', error);

    if (connection) {
      await connection.rollback();
    }

    return buildResponse(500, {
      error: 'Internal Server Error',
      detail: error.message,
    });
  } finally {
    if (connection) await connection.end();
  }
};

function buildResponse(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json; charset=utf-8' },
    body: JSON.stringify(body),
  };
}
