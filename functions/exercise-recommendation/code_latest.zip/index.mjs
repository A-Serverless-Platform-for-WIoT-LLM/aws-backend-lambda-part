import mysql from 'mysql2/promise';
import OpenAI from 'openai';

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const FALLBACK_MESSAGE = "네트워크 연결을 확인하세요.";
const DEFAULT_RESULTS = {
  exercise_month_analysis: FALLBACK_MESSAGE,
  exercise_yesterday_analysis: FALLBACK_MESSAGE,
  exercise_recommendation: FALLBACK_MESSAGE,
};

export const handler = async (event) => {
  let connection;

  try {
    const { encodedId, date } = JSON.parse(event.body);
    connection = await connectToDatabase();

    const userId = await getUserId(connection, encodedId);
    if (!userId) {
      return buildResponse(404, { ...DEFAULT_RESULTS, message: 'User not found' });
    }

    const monthData = await getMonthData(connection, userId, date);
    const yesterdayData = await getYesterdayData(connection, userId, getYesterdayDateString(date));

    const results = await getGptResults(monthData, yesterdayData);

    return buildResponse(200, results);
  } catch (error) {
    return buildResponse(500, {
      ...DEFAULT_RESULTS,
      message: 'Internal server error',
      error: error.message,
    });
  } finally {
    if (connection) await connection.end();
  }
};

async function connectToDatabase() {
  return mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    charset: 'utf8mb4',
  });
}

async function getUserId(conn, encodedId) {
  const [users] = await conn.execute(
    'SELECT id FROM users WHERE encodedId = ?',
    [encodedId]
  );
  return users[0]?.id || null;
}

async function getMonthData(conn, userId, date) {
  const [rows] = await conn.execute(
    `SELECT * FROM fitbit_average
     WHERE user_id = ? AND date = ? AND period_type = '30D'`,
    [userId, date]
  );
  return rows[0] || {};
}

async function getYesterdayData(conn, userId, date) {
  const [rows] = await conn.execute(
    `SELECT * FROM fitbit_activity_summary 
     WHERE user_id = ? AND date = ?`,
    [userId, date]
  );
  return rows[0] || {};
}

function getYesterdayDateString(dateStr) {
  const date = new Date(dateStr);
  date.setDate(date.getDate() - 1);
  return date.toISOString().split('T')[0];
}

async function getGptResults(monthData, yesterdayData) {
  const SYSTEM_ROLE = `
홀로 사는 노인 혹은 가족과 함께 사는 노인 등 전기 노인을 케어하는 애플리케이션 시스템입니다. 
서비스의 목적은 노인의 건강한 생활 습관을 형성하고, 가족 및 의료진에게도 분석 정보를 공유하는 것입니다. 
Fitbit 건강 데이터에 대한 전문적인 분석을 바탕으로, 습관 형성을 위한 동기부여와 격려를 제공하는 것이 목표입니다.

CAUTION
1. 잘못된 데이터나 정보를 포함하지 않았는지 반드시 점검하세요.
2. 모든 조언은 신뢰 가능한 문헌을 바탕으로 제공하세요.
3. 문헌 기반 분석은 하되, 출처는 사용자에게 보여주지 마세요.
4. 제공되지 않은 데이터에 대해 추측하거나 언급하지 마세요.
5. 응답의 논리와 표현은 처음부터 끝까지 일관성 있게 유지하세요.
6. 정상 범주를 벗어나는 수치는 반드시 명확하게 지적하세요.
7. 전문 용어는 일반인이 이해할 수 있게 쉽게 풀어 쓰세요.
8. 본문에 글자 수 정보는 포함하지 마세요.
9. 노인이 실천 가능한 수준이며 권장되는 활동만 제안하세요.
10. 가독성을 높이기 위해 분석 항목에는 이모지를 적절히 활용하세요.

TONE
부드럽고 정중한 말투
`.trim();

  // 데이터 존재 여부 판단 함수
  function hasData(obj) {
    // 객체가 비어있거나 키가 없는 경우 false 반환
    return obj && Object.keys(obj).length > 0;
  }

  const results = { ...DEFAULT_RESULTS };

  // 개별 항목별 조건에 따라 GPT 호출 혹은 고정 메시지 대입

  // exercise_month_analysis
  if (!hasData(monthData)) {
    results.exercise_month_analysis = "해당 데이터가 존재하지 않습니다.";
  }
  // exercise_yesterday_analysis
  if (!hasData(yesterdayData)) {
    results.exercise_yesterday_analysis = "해당 데이터가 존재하지 않습니다.";
  }

  // exercise_recommendation
  // 추천 분석은 두 데이터가 모두 없으면 메시지 할당, 아니면 GPT 호출
  const needRecommendation = hasData(monthData) || hasData(yesterdayData);

  const prompts = [];

  if (hasData(monthData)) {
    prompts.push({
      key: 'exercise_month_analysis',
      message: `[한 달 평균 운동 데이터] ${JSON.stringify(monthData)} 이 데이터를 기반으로 사용자의 한 달간 운동 습관과 건강 상태를 분석해주세요 (200자 이내).`.trim()
    });
  }

  if (hasData(yesterdayData)) {
    prompts.push({
      key: 'exercise_yesterday_analysis',
      message: `[어제 운동 데이터] ${JSON.stringify(yesterdayData)} 이 데이터를 기반으로 어제 하루의 운동 분석해주세요 (200자 이내).`.trim()
    });
  }

  if (needRecommendation) {
    prompts.push({
      key: 'exercise_recommendation',
      message: `
[한 달 평균 운동 데이터] ${JSON.stringify(monthData)}
[어제 운동 데이터] ${JSON.stringify(yesterdayData)}
이 데이터를 기반으로 다음을 알려주세요 (200자 이내):
1. 추천 운동 2~3가지를 제공하고, 구체적인 수치(근거)와 정상 수치에 따른 추천 근거를 제공하세요. 
2. 운동 시 주의사항
      `.trim()
    });
  } else {
    results.exercise_recommendation = "해당 데이터가 존재하지 않습니다.";
  }

  const responses = await Promise.all(
    prompts.map(async ({ key, message }) => {
      try {
        const res = await openai.chat.completions.create({
          model: 'gpt-4',
          messages: [
            { role: 'system', content: SYSTEM_ROLE },
            { role: 'user', content: message },
          ],
        });

        return { key, text: res.choices[0].message.content.trim() };
      } catch (err) {
        return { key, text: 'AI 응답을 가져오지 못했습니다.' };
      }
    })
  );

  responses.forEach(({ key, text }) => {
    results[key] = text;
  });

  return results;
}

function buildResponse(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json; charset=utf-8' },
    body: JSON.stringify(body),
  };
}
