import { JWT } from 'google-auth-library';
import mysql from 'mysql2/promise';
import { createRequire } from 'module';

const require = createRequire(import.meta.url);
const serviceAccount = require('./firebase-sdk-key.json');

async function getAccessToken() {
  const jwtClient = new JWT({
    email: serviceAccount.client_email,
    key: serviceAccount.private_key,
    scopes: ['https://www.googleapis.com/auth/firebase.messaging'],
  });

  const accessToken = await jwtClient.authorize();
  return accessToken.access_token;
}

async function sendNotification(token, title, body) {
  const accessToken = await getAccessToken();

  const message = {
    message: {
      token,
      notification: { title, body },
      android: { priority: 'high' },
    },
  };

  const response = await fetch(
    'https://fcm.googleapis.com/v1/projects/dayinbloom-4dde1/messages:send',
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(message),
    }
  );

  const data = await response.json();
  console.log('FCM Response:', response.status, data);

  return { success: response.ok, response: data };
}

export const handler = async (event) => {
  const encodedId = event.encodedId;

  if (!encodedId) {
    return { statusCode: 400, body: 'encodedId not provided' };
  }

  let connection;

  try {
    connection = await mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
    });

    const [[user]] = await connection.execute(
      `
      SELECT u.id
      FROM users u
      JOIN device_tokens dt ON dt.user_id = u.id AND dt.is_active = TRUE
      JOIN user_alerts ua ON ua.user_id = u.id AND ua.alert_type = 'report_ready' AND ua.is_enabled = TRUE
      WHERE u.encodedId = ? AND u.role = 'senior' AND u.status = 'active'
      `,
      [encodedId]
    );

    if (!user) {
      console.log(`User with encodedId ${encodedId} not eligible for notification.`);
      return { statusCode: 404, body: 'User not eligible or not found' };
    }

    const userId = user.id;

    const [[tokenRow]] = await connection.execute(
      'SELECT fcm_token FROM device_tokens WHERE user_id = ? AND is_active = TRUE',
      [userId]
    );

    if (!tokenRow) {
      console.log(`No FCM token for user ${userId}`);
      return { statusCode: 200, body: 'No FCM token' };
    }

    const fcmToken = tokenRow.fcm_token;
    const title = '꽃이 되는 하루';
    const body = '건강 상태가 궁금하시군요? 리포트를 확인해보세요!';
    const triggeredBy = 'system';
    const notificationType = 'report_ready';

    const { success, response } = await sendNotification(fcmToken, title, body);

    await connection.execute(
      `INSERT INTO notifications (user_id, notification_type, message, triggered_by, sent_at, is_push_sent)
       VALUES (?, ?, ?, ?, NOW(), ?)`,
      [userId, notificationType, body, triggeredBy, success]
    );

    return {
      statusCode: 200,
      body: JSON.stringify({
        success,
        userId,
        response,
      }),
    };
  } catch (err) {
    console.error('Error sending notification:', err);
    return { statusCode: 500, body: 'Internal server error' };
  } finally {
    if (connection) {
      await connection.end();
    }
  }
};
