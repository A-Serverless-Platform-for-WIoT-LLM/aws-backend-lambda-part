import mysql from 'mysql2/promise';

export const handler = async (event) => {
  let connection;

  try {
    const { encodedId } = parseRequestBody(event.body);
    const today = new Date().toISOString().slice(0, 10);

    connection = await createDbConnection();
    const userId = await getUserId(connection, encodedId);

    const [rows] = await connection.execute(
      'SELECT * FROM daily_missions WHERE user_id = ? AND date = ?',
      [userId, today]
    );

    if (rows.length === 0) {
      const newMarker = getMarkerType(1);
      await connection.execute(
        `INSERT INTO daily_missions (user_id, date, mission_quiz, completed_count, marker_type)
         VALUES (?, ?, TRUE, 1, ?)`,
        [userId, today, newMarker]
      );

      return buildResponse(200, {
        message: 'Mission quiz created and marked as completed',
        marker_type: newMarker,
      });
    }

    const mission = rows[0];

    if (mission.mission_quiz === 1) {
      return buildResponse(200, {
        message: 'Mission quiz already completed',
        marker_type: mission.marker_type,
      });
    }

    const updatedCount = mission.completed_count + 1;
    const updatedMarker = getMarkerType(updatedCount);

    await connection.execute(
      `UPDATE daily_missions
       SET mission_quiz = TRUE,
           completed_count = ?,
           marker_type = ?
       WHERE user_id = ? AND date = ?`,
      [updatedCount, updatedMarker, userId, today]
    );

    return buildResponse(200, {
      message: 'Mission quiz updated successfully',
      marker_type: updatedMarker,
    });
  } catch (error) {
    console.error('Lambda error:', error);
    return buildResponse(500, {
      error: 'Internal Server Error',
      detail: error.message,
    });
  } finally {
    if (connection) await connection.end();
  }
};

function parseRequestBody(body) {
  if (!body) throw new Error('Request body is missing');
  const parsed = typeof body === 'string' ? JSON.parse(body) : body;

  if (!parsed.encodedId) {
    throw new Error('Missing required field: encodedId');
  }

  return parsed;
}

function getMarkerType(count) {
  if (count <= 0) return 'none';
  if (count === 1) return 'seed';
  if (count === 2) return 'sprout';
  if (count === 3) return 'leaf';
  if (count === 4) return 'flowerbud';
  return 'flower';
}

async function createDbConnection() {
  return await mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    charset: 'utf8mb4',
  });
}

async function getUserId(connection, encodedId) {
  const [rows] = await connection.execute(
    'SELECT id FROM users WHERE encodedId = ?',
    [encodedId]
  );

  if (rows.length === 0) {
    throw new Error('User not found');
  }

  return rows[0].id;
}

function buildResponse(statusCode, body) {
  return {
    statusCode,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Access-Control-Allow-Origin': '*',
    },
    body: JSON.stringify(body),
  };
}
