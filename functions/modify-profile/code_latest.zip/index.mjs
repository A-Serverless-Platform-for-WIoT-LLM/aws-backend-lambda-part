import mysql from 'mysql2/promise';

export const handler = async (event) => {
  let connection;

  try {
    const {
      encodedId,
      username,
      birth_date,
      gender,
      address,
      phone_number,
      height,
      weight,
      breakfast_time,
      lunch_time,
      dinner_time,
    } = JSON.parse(event.body);

    if (!encodedId) throw new Error('Missing encodedId');

    connection = await mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
      charset: 'utf8mb4',
    });

    const [result] = await connection.execute(
      `UPDATE users
       SET username = ?, birth_date = ?, gender = ?, address = ?, phone_number = ?,
           height = ?, weight = ?, breakfast_time = ?, lunch_time = ?, dinner_time = ?
       WHERE encodedId = ?`,
      [
        username,
        birth_date,
        gender,
        address,
        phone_number,
        height,
        weight,
        breakfast_time,
        lunch_time,
        dinner_time,
        encodedId,
      ]
    );

    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'Profile updated successfully', affectedRows: result.affectedRows }),
    };
  } catch (error) {
    console.error('Modify-profile error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Internal Server Error', detail: error.message }),
    };
  } finally {
    if (connection) await connection.end();
  }
};
