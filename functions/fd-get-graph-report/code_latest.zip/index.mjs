import { S3Client, GetObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import mysql from 'mysql2/promise';

const s3 = new S3Client({ region: 'ap-northeast-2' });
const BUCKET_NAME = 'fitbit-graph-s3-bucket';

export const handler = async (event) => {
  let connection;

  try {
    const { encodedId, report_date, graph_type } = JSON.parse(event.body);

    if (!encodedId || !report_date || !graph_type) {
      throw new Error("필수 파라미터 누락");
    }

    connection = await mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
      charset: 'utf8mb4',
    });

    const [rows] = await connection.execute(
      'SELECT username FROM users WHERE encodedId = ?',
      [encodedId]
    );
    if (!rows.length) throw new Error('해당 사용자가 존재하지 않습니다');

    const username = rows[0].username;
    const fileName = `${report_date}_${username}_${graph_type}.png`;
    const key = `graphs/${fileName}`;

    // console.log("username:", username);
    // console.log("fileName:", fileName);
    // console.log("S3 key:", key);

    const presignedUrl = await getSignedUrl(
      s3,
      new GetObjectCommand({
        Bucket: BUCKET_NAME,
        Key: key,
        ResponseContentType: 'image/png',
      }),
      { expiresIn: 300 }
    );
    
    const cleanedUrl = presignedUrl.replace(/\n/g, '');
    
    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json; charset=utf-8',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({ cleanedUrl }),
    };
  } catch (err) {
    console.error('Lambda error:', err);
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json; charset=utf-8',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({ error: err.message }),
    };
  } finally {
    if (connection) await connection.end();
  }
};
