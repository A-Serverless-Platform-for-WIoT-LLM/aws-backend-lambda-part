import mysql from 'mysql2/promise';

export const handler = async (event) => {
  let connection;

  try {
    const { encodedId, fcmToken, platform } = JSON.parse(event.body);

    if (!encodedId || !fcmToken || !platform) {
      throw new Error('Missing required fields');
    }

    connection = await mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
      charset: 'utf8mb4',
    });

    const [users] = await connection.execute(
      'SELECT id FROM users WHERE encodedId = ?',
      [encodedId]
    );

    if (users.length === 0) {
      throw new Error('User not found for given encodedId');
    }

    const userId = users[0].id;

    const [rows] = await connection.execute(
      'SELECT * FROM device_tokens WHERE user_id = ?',
      [userId]
    );

    let query, values;

    if (rows.length > 0) {
      query = `
        UPDATE device_tokens
        SET fcm_token = ?, platform = ?, is_active = TRUE
        WHERE user_id = ?;
      `;
      values = [fcmToken, platform, userId];
    } else {
      query = `
        INSERT INTO device_tokens (user_id, fcm_token, platform, is_active)
        VALUES (?, ?, ?, TRUE);
      `;
      values = [userId, fcmToken, platform];
    }

    const [results] = await connection.execute(query, values);

    console.log('Token saved or updated successfully:', results);
    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'Token saved or updated successfully' }),
    };
  } catch (error) {
    console.error('Error saving or updating token:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Failed to save or update token', error: error.message }),
    };
  } finally {
    if (connection) {
      await connection.end();
    }
  }
};
