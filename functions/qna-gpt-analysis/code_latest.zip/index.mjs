import { OpenAI } from 'openai';

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export const handler = async (event) => {
  console.debug('Received event:', JSON.stringify(event, null, 2));

  if (!event.body) {
    return buildResponse(400, {
      error: 'Invalid request format. Body is missing.',
    });
  }

  try {
    const choiceResult = extractChoiceResult(event);

    console.debug('Extracted choice_result:', choiceResult);

    const gptAnalysis = await getGptAnalysis(choiceResult);

    return buildResponse(200, { analysis: gptAnalysis });
  } catch (error) {
    console.error('[GPT Lambda Error]', error);
    return buildResponse(500, {
      error: 'Internal Server Error',
      detail: error.message,
    });
  }
};


function extractChoiceResult(event) {
  let bodyStr = event.body;
  if (event.isBase64Encoded) {
    bodyStr = Buffer.from(bodyStr, 'base64').toString('utf-8');
  }

  let parsedBody;
  try {
    parsedBody = JSON.parse(bodyStr);
  } catch (err) {
    throw new Error('JSON 파싱 실패: ' + err.message);
  }

  const choiceResult = parsedBody.choice_result;
  if (!choiceResult) {
    throw new Error("Missing 'choice_result' field in request body");
  }

  return choiceResult;
}

async function getGptAnalysis(choiceResult) {
  const systemRole = `
홀로 사는 노인 혹은 가족과 함께 사는 노인 등 전기 노인을 케어하는 애플리케이션 시스템입니다. 
서비스의 목적은 노인의 건강한 생활 습관을 형성하고, 가족 및 의료진에게도 분석 정보를 공유하는 것입니다. 
Fitbit 건강 데이터에 대한 전문적인 분석을 바탕으로, 습관 형성을 위한 동기부여와 격려를 제공하는 것이 목표입니다.

CAUTION
1. 잘못된 데이터나 정보를 포함하지 않았는지 반드시 점검하세요.
2. 모든 조언은 신뢰 가능한 문헌을 바탕으로 제공하세요.
3. 문헌 기반 분석은 하되, 출처는 사용자에게 보여주지 마세요.
4. 제공되지 않은 데이터에 대해 추측하거나 언급하지 마세요.
5. 응답의 논리와 표현은 처음부터 끝까지 일관성 있게 유지하세요.
6. 정상 범주를 벗어나는 수치는 반드시 명확하게 지적하세요.
7. 전문 용어는 일반인이 이해할 수 있게 쉽게 풀어 쓰세요.
8. 본문에 글자 수 정보는 포함하지 마세요.
9. 노인이 실천 가능한 수준이며 권장되는 활동만 제안하세요. 
10. 가독성을 높이기 위해 분석 항목에는 이모지를 적절히 활용하세요.

TONE
부드럽고 정중한 말투
`.trim();

  const userPrompt = `
CHOICE_RESULT 데이터를 바탕으로 긍정적, 부정적 주관에 대해 의학과 심리학의 전문적인 지식을 바탕으로 분석을 제공해주세요. 
해결 방안 및 동기 부여도 함께 제공해주세요. (300자 이내)

CHOICE_RESULT: ${JSON.stringify(choiceResult, null, 2)}
`.trim();

  const messages = [
    { role: 'system', content: systemRole },
    { role: 'user', content: userPrompt },
  ];

  const response = await openai.chat.completions.create({
    model: 'gpt-4',
    messages,
    temperature: 0,
  });

  return response.choices[0]?.message?.content ?? '분석 결과 생성 실패';
}

function buildResponse(statusCode, body) {
  return {
    statusCode,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
    },
    body: JSON.stringify(body),
  };
}
