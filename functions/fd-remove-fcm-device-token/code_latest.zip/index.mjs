import mysql from 'mysql2/promise';

export const handler = async (event) => {
  let connection;

  console.log('Lambda invoked');
  console.log('Event:', JSON.stringify(event));

  try {
    const kakaoUserId = event.queryStringParameters?.kakaoUserId;
    console.log('Parsed kakaoUserId:', kakaoUserId);

    if (!kakaoUserId) {
      console.warn('kakaoUserId missing in query parameters');
      return {
        statusCode: 400,
        body: JSON.stringify({ message: 'Missing kakaoUserId in query parameters' }),
      };
    }

    console.log('Connecting to MySQL...');
    connection = await mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
      charset: 'utf8mb4',
    });
    console.log('MySQL connection established');

    const [users] = await connection.execute(
      'SELECT id FROM users WHERE kakao_user_id = ?',
      [kakaoUserId]
    );
    console.log('User lookup result:', users);

    if (users.length === 0) {
      console.warn('User not found for kakaoUserId:', kakaoUserId);
      return {
        statusCode: 404,
        body: JSON.stringify({ message: 'User not found' }),
      };
    }

    const userId = users[0].id;
    console.log(`Found userId: ${userId} for kakaoUserId: ${kakaoUserId}`);

    const [result] = await connection.execute(
      'UPDATE device_tokens SET is_active = FALSE WHERE user_id = ?',
      [userId]
    );
    console.log('Update result:', result);

    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'FCM token deactivated successfully', affectedRows: result.affectedRows }),
    };
  } catch (error) {
    console.error('Error deleting FCM token:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Failed to delete FCM token', error: error.message }),
    };
  } finally {
    if (connection) {
      await connection.end();
      console.log('MySQL connection closed');
    }
  }
};
