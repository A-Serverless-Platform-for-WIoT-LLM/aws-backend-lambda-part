import mysql from 'mysql2/promise';

export const handler = async (event) => {
  let connection;

  try {
    const {
      encodedId,
      report_date,
      kakao_user_id,
      role
    } = event.queryStringParameters || {};

    if (!encodedId || !report_date || !kakao_user_id || !role) {
      return buildResponse(400, {
        error: "Missing required query parameters: encodedId, report_date, kakao_user_id, role"
      });
    }

    connection = await createDbConnection();

    const [[user]] = await connection.execute(
      `SELECT id FROM users WHERE kakao_user_id = ? AND role = 'guardian_or_doctor'`,
      [kakao_user_id]
    );

    if (!user) {
      return buildResponse(404, { error: `해당 ${role} 계정을 찾을 수 없습니다.` });
    }

    const [[senior]] = await connection.execute(
      `SELECT id FROM users WHERE encodedId = ?`,
      [encodedId]
    );

    if (!senior) {
      return buildResponse(404, { error: "해당 encodedId 어르신을 찾을 수 없습니다." });
    }

    const [[report]] = await connection.execute(
      `SELECT id FROM daily_health_reports WHERE user_id = ? AND report_date = ?`,
      [senior.id, report_date]
    );
    console.log('Report:', report);

    if (!report) {
      return buildResponse(404, { error: "건강 리포트를 찾을 수 없습니다." });
    }

    const [[comment]] = await connection.execute(
      `SELECT content FROM comments WHERE report_id = ? AND author_id = ? AND role = ?`,
      [report.id, user.id, role]
    );
    console.log('Comment:', comment);

    return buildResponse(200, {
      content: comment?.content || '',
    });

  } catch (err) {
    console.error('[Lambda Error]', err);
    return buildResponse(500, { error: err.message || String(err) });
  } finally {
    await connection?.end();
  }
};

function buildResponse(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json; charset=utf-8' },
    body: JSON.stringify(body),
  };
}

async function createDbConnection() {
  return mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    charset: 'utf8mb4',
  });
}
