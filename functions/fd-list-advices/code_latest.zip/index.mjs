import mysql from 'mysql2/promise';

export const handler = async (event) => {
  let connection;

  try {
    const { encodedId, report_date, role } = parseQueryParams(event.queryStringParameters);

    connection = await createDbConnection();

    const [userRow] = await connection.execute(
      'SELECT id FROM users WHERE encodedId = ?',
      [encodedId]
    );
    if (!userRow.length) throw new Error('해당 encodedId 사용자가 존재하지 않습니다.');
    const userId = userRow[0].id;

    const [reportRow] = await connection.execute(
      'SELECT id FROM daily_health_reports WHERE user_id = ? AND report_date = ?',
      [userId, report_date]
    );
    if (!reportRow.length) throw new Error('해당 날짜의 건강 리포트가 존재하지 않습니다.');
    const reportId = reportRow[0].id;

    const [comments] = await connection.execute(
      `SELECT c.content, u.username AS author
       FROM comments c
       JOIN users u ON c.author_id = u.id
       WHERE c.report_id = ? AND c.role = ?`,
      [reportId, role]
    );

    return buildResponse(200, { comments });

  } catch (error) {
    console.error('Lambda error:', error);
    return buildResponse(500, {
      error: 'Internal Server Error',
      detail: error.message,
    });
  } finally {
    await connection?.end();
  }
};

function parseQueryParams(params) {
  if (!params) throw new Error('Query parameters are missing');

  const { encodedId, report_date, role } = params;
  if (!encodedId || !report_date || !role) {
    throw new Error('Missing required query parameters: encodedId, report_date or role');
  }

  const cleaned = report_date.replace(/\s/g, '').replace(/\//g, '-');
  const parsedDate = new Date(cleaned);
  if (isNaN(parsedDate.getTime())) {
    throw new Error(`Invalid date format: ${report_date}`);
  }

  return {
    encodedId,
    report_date: parsedDate.toISOString().split('T')[0],
    role: role.toLowerCase(),
  };
}

function buildResponse(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json; charset=utf-8' },
    body: JSON.stringify(body),
  };
}

async function createDbConnection() {
  return mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    charset: 'utf8mb4',
  });
}
