import { S3Client, GetObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import mysql from 'mysql2/promise';

const s3 = new S3Client({ region: 'ap-northeast-2' });
const BUCKET_NAME = 'fitbit-report-s3-bucket';

export const handler = async (event) => {
  let connection;

  try {
    const encodedId = event.queryStringParameters?.encodedId;
    const report_date = event.queryStringParameters?.report_date;

    if (!encodedId || !report_date) {
      return {
        statusCode: 400,
        headers: {
          'Content-Type': 'application/json; charset=utf-8',
          'Access-Control-Allow-Origin': '*',
        },
        body: JSON.stringify({ error: 'Missing encodedId or report_date' }),
      };
    }

    connection = await mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
      charset: 'utf8mb4',
    });

    const [userRows] = await connection.execute(
      'SELECT username FROM users WHERE encodedId = ?',
      [encodedId]
    );

    if (userRows.length === 0) {
      return {
        statusCode: 404,
        headers: {
          'Content-Type': 'application/json; charset=utf-8',
          'Access-Control-Allow-Origin': '*',
        },
        body: JSON.stringify({ error: 'User not found' }),
      };
    }

    const username = userRows[0].username;
    const fileName = `건강리포트_${report_date}_${username}.pdf`;
    const key = `healthreport/${fileName}`;

    const presignedUrl = await getSignedUrl(s3, new GetObjectCommand({
      Bucket: BUCKET_NAME,
      Key: key,
      ResponseContentType: 'application/pdf',
    }), { expiresIn: 300 });

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json; charset=utf-8',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({ presignedUrl }),
    };
  } catch (err) {
    console.error('Lambda error:', err);
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json; charset=utf-8',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({ error: err.message }),
    };
  } finally {
    if (connection) await connection.end();
  }
};
