import mysql from 'mysql2/promise';

export const handler = async (event) => {
  let connection;
  try {
    const { encodedId, date } = JSON.parse(event.body);
    
    if (!encodedId || !date) {
      return buildResponse(400, { error: 'Missing required fields' });
    }

    connection = await mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
      charset: 'utf8mb4'
    });

    const [[user]] = await connection.execute(
      'SELECT id FROM users WHERE encodedId = ?',
      [encodedId]
    );

    if (!user) {
      return buildResponse(404, { error: 'User not found' });
    }

    const start = new Date(date);
    start.setMonth(start.getMonth() - 1);
    const formattedStart = start.toISOString().split('T')[0] + ' 00:00:00';
    const formattedEnd = `${date} 23:59:59`;

    const [notifications] = await connection.execute(
      `SELECT id, user_id, notification_type, message, triggered_by, sent_at, is_read, is_push_sent
       FROM notifications
       WHERE user_id = ? AND sent_at BETWEEN ? AND ?
       ORDER BY sent_at DESC`,
      [user.id, formattedStart, formattedEnd]
    );

    console.log(`Found ${notifications.length} notifications for user ${user.id}`);
    
    return buildResponse(200, notifications);

  } catch (err) {
    console.error('Lambda error:', err);
    return buildResponse(500, { 
      error: 'Internal Server Error', 
      detail: err.message 
    });
  } finally {
    if (connection) {
      await connection.end();
    }
  }
};

function buildResponse(statusCode, body) {
  return {
    statusCode,
    headers: { 
      'Content-Type': 'application/json; charset=utf-8',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type'
    },
    body: JSON.stringify(body),
  };
}