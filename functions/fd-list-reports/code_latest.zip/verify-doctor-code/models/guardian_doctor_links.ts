import * as Sequelize from 'sequelize';
import { DataTypes, Model, Optional } from 'sequelize';
import type { Users, UsersId } from './users';

export interface GuardianDoctorLinksAttributes {
  id: number;
  user_id: number;
  senior_id: number;
  role: 'guardian' | 'doctor';
  created_at?: Date;
  updated_at?: Date;
}

export type GuardianDoctorLinksPk = 'id';
export type GuardianDoctorLinksId = GuardianDoctorLinks[GuardianDoctorLinksPk];
export type GuardianDoctorLinksOptionalAttributes =
  | 'id'
  | 'created_at'
  | 'updated_at';
export type GuardianDoctorLinksCreationAttributes = Optional<
  GuardianDoctorLinksAttributes,
  GuardianDoctorLinksOptionalAttributes
>;

export class GuardianDoctorLinks
  extends Model<
    GuardianDoctorLinksAttributes,
    GuardianDoctorLinksCreationAttributes
  >
  implements GuardianDoctorLinksAttributes
{
  declare id: number;
  declare user_id: number;
  declare senior_id: number;
  declare role: 'guardian' | 'doctor';
  declare created_at?: Date;
  declare updated_at?: Date;

  // GuardianDoctorLinks belongsTo Users via user_id
  user!: Users;
  getUser!: Sequelize.BelongsToGetAssociationMixin<Users>;
  setUser!: Sequelize.BelongsToSetAssociationMixin<Users, UsersId>;
  createUser!: Sequelize.BelongsToCreateAssociationMixin<Users>;
  // GuardianDoctorLinks belongsTo Users via senior_id
  senior!: Users;
  getSenior!: Sequelize.BelongsToGetAssociationMixin<Users>;
  setSenior!: Sequelize.BelongsToSetAssociationMixin<Users, UsersId>;
  createSenior!: Sequelize.BelongsToCreateAssociationMixin<Users>;

  static initModel(sequelize: Sequelize.Sequelize): typeof GuardianDoctorLinks {
    return GuardianDoctorLinks.init(
      {
        id: {
          autoIncrement: true,
          type: DataTypes.BIGINT,
          allowNull: false,
          primaryKey: true,
        },
        user_id: {
          type: DataTypes.BIGINT,
          allowNull: false,
          references: {
            model: 'users',
            key: 'id',
          },
        },
        senior_id: {
          type: DataTypes.BIGINT,
          allowNull: false,
          references: {
            model: 'users',
            key: 'id',
          },
        },
        role: {
          type: DataTypes.ENUM('guardian', 'doctor'),
          allowNull: false,
        },
        created_at: {
          type: DataTypes.DATE,
          allowNull: true,
          defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
        },
        updated_at: {
          type: DataTypes.DATE,
          allowNull: true,
          defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
        },
      },
      {
        sequelize,
        tableName: 'guardian_doctor_links',
        timestamps: false,
        indexes: [
          {
            name: 'PRIMARY',
            unique: true,
            using: 'BTREE',
            fields: [{ name: 'id' }],
          },
          {
            name: 'user_id',
            using: 'BTREE',
            fields: [{ name: 'user_id' }],
          },
          {
            name: 'senior_id',
            using: 'BTREE',
            fields: [{ name: 'senior_id' }],
          },
        ],
      }
    );
  }
}
