import { APIGatewayProxyHandler } from 'aws-lambda';
import { Sequelize } from 'sequelize';
import { Users } from './models/users';
import { GuardianDoctorLinks } from './models/guardian_doctor_links';

export const handler: APIGatewayProxyHandler = async event => {
  console.log('이벤트를 전송받았습니다:');
  console.log(event);

  const body = JSON.parse(event.body || '{}');
  const { kakao_user_id, doctor_code, encodedId, report_date } = body;
  if (!kakao_user_id || !doctor_code || !encodedId) {
    const errMsg = `필수 데이터 누락. body 에 kakao_user_id, doctor_code, encodedId 가 다 있는지 확인하세요`;
    return {
      statusCode: 400,
      body: JSON.stringify({ error: errMsg }),
    };
  }

  // REGION model initialization
  const sequelize = new Sequelize({
    dialect: 'mysql',
    host: process.env.DB_HOST,
    username: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    logging: false,
  });
  const users = Users.initModel(sequelize);
  const guardianDoctorLinks = GuardianDoctorLinks.initModel(sequelize);
  // ENDREGION

  let statusCode: number;
  let response: object;

  try {
    const user = await users.findOne({ where: { kakao_user_id } });
    if (!user) {
      await sequelize.close();
      const errMsg = `존재하지 않는 유저: ${kakao_user_id}`;
      console.error(errMsg);
      return {
        statusCode: 400,
        body: JSON.stringify({ error: errMsg }),
      };
    }
    const senior = await users.findOne({ where: { encodedId } });
    if (!senior) {
      await sequelize.close();
      const errMsg = `존재하지 않는 유저: ${encodedId}`;
      console.error(errMsg);
      return {
        statusCode: 400,
        body: JSON.stringify({ error: errMsg }),
      };
    }
    if (senior.doctor_code !== doctor_code) {
      await sequelize.close();
      const errMsg = `노인 ${encodedId} 의 의사 코드와 주어진 의사 코드가 일치하지 않습니다`;
      console.error(errMsg);
      return {
        statusCode: 403,
        body: JSON.stringify({ error: errMsg }),
      };
    }

    const association = await guardianDoctorLinks.findOne({
      where: {
        user_id: user.id,
        senior_id: senior.id,
        role: 'doctor',
      },
    });
    if (!association) {
      await sequelize.close();
      const errMsg = `유저 ${kakao_user_id} 와 노인 ${encodedId} 는 의사-노인 관계로 이어져 있지 않습니다`;
      console.error(errMsg);
      return {
        statusCode: 403,
        body: JSON.stringify({ error: errMsg }),
      };
    }

    console.log(`유저 ${kakao_user_id} 는 노인 ${encodedId} 의 의사입니다.`);
    statusCode = 204;
    response = {};
  } catch (error) {
    const errMsg = error instanceof Error ? error.message : String(error);
    console.error(errMsg);

    statusCode = 500;
    response = { error: errMsg };
  }

  await sequelize.close();
  return { statusCode, body: JSON.stringify(response) };
};
