import mysql from 'mysql2/promise';

export const handler = async (event) => {
  let connection;
  try {
    console.log('event:', JSON.stringify(event));
    const encodedId = event.queryStringParameters?.encodedId;
    console.log('encodedId:', encodedId);

    if (!encodedId) {
      return buildResponse(400, { error: 'Missing encodedId' });
    }

    connection = await mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
      charset: 'utf8mb4',
    });

    console.log('Connected to DB');

    const [userRows] = await connection.execute(
      'SELECT id FROM users WHERE encodedId = ?',
      [encodedId]
    );
    console.log('userRows:', userRows);

    if (userRows.length === 0) {
      return buildResponse(404, { error: 'User not found' });
    }

    const userId = userRows[0].id;
    console.log('userId:', userId);

    const [missionRows] = await connection.execute(
      'SELECT date, marker_type FROM daily_missions WHERE user_id = ?',
      [userId]
    );
    console.log('missionRows:', missionRows);

    const [reportRows] = await connection.execute(
      `SELECT report_date 
       FROM daily_health_reports 
       WHERE user_id = ? AND report_status = 'completed'`,
      [userId]
    );

    console.log('reportRows:', reportRows);

    const reportDates = new Set(reportRows.map(r => {
      const d = new Date(r.report_date);
      return d.toISOString().split('T')[0];
    }));

    const enriched = missionRows.map(row => {
      const d = new Date(row.date);
      const date = d.toISOString().split('T')[0];
      return {
        date,
        marker_type: row.marker_type,
        has_report: reportDates.has(date),
      };
    });

    console.log('🧾 enriched:', enriched);

    return buildResponse(200, enriched);

  } catch (error) {
    console.error('Lambda error:', error); // <-- 여기가 로그 안 나오면 이유 있음
    return buildResponse(500, {
      error: 'Internal Server Error',
      message: error?.message ?? 'Unknown error',
      stack: error?.stack ?? 'No stack trace',
    });
  } finally {
    if (connection) {
      console.log('🧹 Closing DB connection');
      await connection.end();
    }
  }
};

function buildResponse(statusCode, body) {
  return {
    statusCode,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Access-Control-Allow-Origin': '*',
    },
    body: JSON.stringify(body),
  };
}
