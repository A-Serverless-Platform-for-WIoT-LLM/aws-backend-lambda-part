import os
os.environ['MPLCONFIGDIR'] = '/tmp'
import pymysql
import matplotlib.pyplot as plt
import boto3
from io import BytesIO
import matplotlib
import matplotlib.dates as mdates
from datetime import datetime, timedelta
from fpdf import FPDF
from openai import OpenAI
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta
import base64
import json

openai_client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])

DB_HOST = os.environ["DB_HOST"]
DB_USER = os.environ["DB_USER"]
DB_PASSWORD = os.environ["DB_PASSWORD"]
DB_NAME = os.environ["DB_NAME"]
S3_BUCKET_GRAPH = os.environ["S3_BUCKET_GRAPH"]
S3_BUCKET_PDF = os.environ["S3_BUCKET_PDF"]

lambda_client = boto3.client('lambda')

def invoke_alarm_lambda(encoded_id):
    payload = {
        "encodedId": encoded_id
    }
    lambda_client.invoke(
        FunctionName='auto-report-alarm', 
        InvocationType='RequestResponse',
        Payload=json.dumps(payload)
    )

def invoke_fd_alarm_lambda(encoded_id):
    payload = {
        "encodedId": encoded_id
    }
    lambda_client.invoke(
        FunctionName='fd-auto-report-alarm', 
        InvocationType='RequestResponse',
        Payload=json.dumps(payload)
    )

def remove_unsupported_chars(text):
    return ''.join(c for c in text if 32 <= ord(c) <= 126 or ord(c) >= 0xAC00)

def wrap_text(text, max_length=55):
    import textwrap
    wrapped = []
    for paragraph in text.split('\n'): 
        lines = textwrap.wrap(paragraph, width=max_length, break_long_words=False)
        if lines:
            wrapped.extend(lines)
        else:
            wrapped.append('') 
    return '\n'.join(wrapped)

def fetch_fitbit_data(query):
    conn = pymysql.connect(
        host=DB_HOST,
        user=DB_USER,
        password=DB_PASSWORD,
        database=DB_NAME,
        cursorclass=pymysql.cursors.DictCursor
    )
    try:
        with conn.cursor() as cursor:
            cursor.execute(query)
            data = cursor.fetchall()
        return data
    finally:
        conn.close()

def prepare_activity_data(data):
    for d in data:
        d['created_at'] = datetime.strptime(d['date'], "%Y-%m-%d %H:%M:%S") if isinstance(d['date'], str) else d['date']
    return data

def prepare_sleep_data(data):
    for d in data:
        d['created_at'] = datetime.strptime(d['startTime'], "%Y-%m-%d %H:%M:%S") if isinstance(d['startTime'], str) else d['startTime']
    return data

def upload_to_s3(img_buffer, filename, bucket):
    s3 = boto3.client('s3')
    s3.put_object(Bucket=bucket, Key=filename, Body=img_buffer, ContentType='image/png')
    return f"https://{bucket}.s3.amazonaws.com/{filename}"

def upload_pdf_to_s3(pdf_buffer, username, today):
    file_name = f"healthreport/건강리포트_{today}_{username}.pdf"
    s3 = boto3.client('s3')
    s3.put_object(Bucket=S3_BUCKET_PDF, Key=file_name, Body=pdf_buffer, ContentType='application/pdf')
    return f"https://{S3_BUCKET_PDF}.s3.amazonaws.com/{file_name}"


def generate_sleep_step_graph_week(data):
    data = sorted(data, key=lambda x: x['created_at'])
    timestamps = [d['created_at'] for d in data]
    deep_list = [d['deep_sleep_hours'] for d in data]
    light_list = [d['light_sleep_hours'] for d in data]
    rem_list = [d['rem_sleep_hours'] for d in data]
    awake_list = [min(d['minutesAwake'] / 60, 12) for d in data]
    
    colors = {
        'deep': '#1e3a8a',
        'light': '#3b82f6',
        'rem': '#8b5cf6',
        'awake': '#f59e0b'
    }
    
    N = len(timestamps)
    fig_width = 10 
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(fig_width, 10), height_ratios=[3, 1])
    
    for i, timestamp in enumerate(timestamps):
        total_sleep = deep_list[i] + light_list[i] + rem_list[i]
        sleep_efficiency = total_sleep / (total_sleep + awake_list[i]) if (total_sleep + awake_list[i]) > 0 else 0
        sizes = [deep_list[i], light_list[i], rem_list[i], awake_list[i]]
        colors_list = [colors['deep'], colors['light'], colors['rem'], colors['awake']]
        
        center_x = i
        ax1.pie(
            sizes, colors=colors_list, startangle=90,
            center=(center_x, 0), radius=0.4,
            wedgeprops=dict(width=0.3, edgecolor='white', linewidth=2)
        )
        ax1.text(center_x, 0, f'{sleep_efficiency:.0%}', ha='center', va='center',
                fontsize=10, fontweight='bold')
    
    ax1.set_xlim(-0.5, N - 0.5)
    ax1.set_ylim(-0.5, 0.5)
    ax1.set_aspect('equal')
    ax1.set_xticks(range(N))
    ax1.set_xticklabels([t.strftime('%m/%d\n%H:%M') for t in timestamps])
    ax1.set_title('일일 수면 단계 분포', fontsize=14, fontweight='bold', pad=20)
    
    legend_elements = [
        plt.Rectangle((0, 0), 1, 1, facecolor=colors['deep'], label='깊은 수면'),
        plt.Rectangle((0, 0), 1, 1, facecolor=colors['light'], label='얕은 수면'),
        plt.Rectangle((0, 0), 1, 1, facecolor=colors['rem'], label='렘 수면'),
        plt.Rectangle((0, 0), 1, 1, facecolor=colors['awake'], label='깨어있는 시간')
    ]
    ax1.legend(handles=legend_elements, loc='upper right', bbox_to_anchor=(1.12, 1))
    ax1.set_ylabel('수면 효율', fontsize=12, rotation=0, labelpad=50)

    total_sleep_hours = [d + l + r for d, l, r in zip(deep_list, light_list, rem_list)]
    
    fixed_x_positions = [0, 1, 2, 3, 4]
    fixed_x_labels = ['00:00', '07:00', '10:00', '14:00', '19:00']
    
    for i, (sleep_hours) in enumerate(total_sleep_hours):
        if i < len(fixed_x_positions):  
            bars = ax2.bar(
                fixed_x_positions[i], sleep_hours, width=0.6,  
                color='#6366f1', alpha=0.7, edgecolor='white', linewidth=1
            )
            ax2.text(fixed_x_positions[i], sleep_hours + 0.1, f'{sleep_hours:.1f}시간', 
                    ha='center', va='bottom', fontsize=9)
    
    ax2.set_xlim(-0.5, 4.5)  
    ax2.set_xticks(fixed_x_positions)
    ax2.set_xticklabels(fixed_x_labels)
    ax2.set_ylabel('총 수면시간\n(시간)', fontsize=10, rotation=0, labelpad=40)
    ax2.set_xlabel('시각', fontsize=12)
    ax2.grid(True, alpha=0.3, axis='y')
    ax2.set_ylim(0, max(total_sleep_hours) * 1.2 if total_sleep_hours else 1)
    
    plt.tight_layout()
    img_buffer = BytesIO()
    plt.savefig(img_buffer, format='png', dpi=300, bbox_inches='tight')
    img_buffer.seek(0)
    plt.close()
    
    return img_buffer


def generate_heart_rate(data):
    created_at = [d['created_at'] for d in data]
    heart_rate = [d['heart_rate'] for d in data]
    
    plt.figure(figsize=(12, 6))
    
    plt.gca().set_facecolor('#f8fafc')
    
    colors = []
    for hr in heart_rate:
        if hr < 60:
            colors.append('#22c55e')  
        elif hr < 80:
            colors.append('#3b82f6')  
        elif hr < 100:
            colors.append('#f59e0b') 
        else:
            colors.append('#ef4444')  
    
    plt.fill_between(created_at, heart_rate, alpha=0.3, color='#0ABAB5')
    plt.plot(created_at, heart_rate, color='#0ABAB5', linewidth=3, marker='o', 
             markersize=8, markerfacecolor='white', markeredgecolor='#0ABAB5', 
             markeredgewidth=2, label='심박수')
    
    avg_hr = sum(heart_rate) / len(heart_rate)
    plt.axhline(y=avg_hr, color='#ef4444', linestyle='--', alpha=0.7, 
                label=f'평균: {avg_hr:.0f} bpm')
    
    plt.axhspan(60, 100, alpha=0.1, color='#22c55e', label='정상 범위')
    
    for i, (time, hr) in enumerate(zip(created_at, heart_rate)):
        if i % 2 == 0:  
            plt.annotate(f'{hr}', (time, hr), textcoords="offset points", 
                        xytext=(0,10), ha='center', fontsize=9, 
                        bbox=dict(boxstyle='round,pad=0.3', facecolor='white', alpha=0.8))
    
    plt.xlabel('시간', fontsize=12)
    plt.ylabel('평균 심박수\n(bpm)', rotation=0, labelpad=40, fontsize=12)
    plt.title('일일 평균 심박수 변화', fontsize=14, fontweight='bold')
    plt.legend(loc='upper right')
    
    ax = plt.gca()
    ax.xaxis.set_major_locator(mdates.AutoDateLocator())
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M'))
    
    plt.grid(True, alpha=0.3, linestyle='-', linewidth=0.5)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.spines['left'].set_color('#e2e8f0')
    ax.spines['bottom'].set_color('#e2e8f0')
    
    plt.tight_layout()
    img_buffer = BytesIO()
    plt.savefig(img_buffer, format='png', dpi=300, bbox_inches='tight')
    img_buffer.seek(0)
    plt.close()
    return img_buffer


def generate_step_and_calories_graph(data):
    created_at = [d['created_at'] for d in data]
    steps = [d['steps'] for d in data]
    calories = [d['calories_total'] for d in data]
    
    fig, ax1 = plt.subplots(figsize=(12, 6))
    fig.patch.set_facecolor('#fafafa')
    
    step_color = '#FF5C5C'
    ax1.plot(created_at, steps, marker='o', color=step_color, 
             linewidth=3, markersize=8, markerfacecolor='white',
             markeredgecolor=step_color, markeredgewidth=2, label='걸음 수')
    
    ax1.fill_between(created_at, steps, alpha=0.2, color=step_color)
    
    ax1.set_ylabel('걸음 수', rotation=0, labelpad=40, fontsize=12)
    ax1.tick_params(axis='y', labelcolor=step_color)
    ax1.spines['left'].set_color(step_color)
    
    ax2 = ax1.twinx()
    
    calorie_color = '#3B82F6'
    ax2.plot(created_at, calories, marker='s', color=calorie_color, 
             linewidth=3, markersize=8, markerfacecolor='white',
             markeredgecolor=calorie_color, markeredgewidth=2, label='칼로리 소모')
    
    ax2.fill_between(created_at, calories, alpha=0.2, color=calorie_color)
    
    ax2.set_ylabel('칼로리\n소모', rotation=0, labelpad=40, fontsize=12)
    ax2.tick_params(axis='y', labelcolor=calorie_color)
    ax2.spines['right'].set_color(calorie_color)
    
    ax1.set_xlabel('시간', fontsize=12)
    plt.title('하루 동안의 걸음 수 및 칼로리 소모 변화', fontsize=14, fontweight='bold')
    
    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, loc='upper left')
    
    ax1.grid(True, alpha=0.3, axis='y')
    ax1.spines['top'].set_visible(False)
    ax2.spines['top'].set_visible(False)
    
    ax1.xaxis.set_major_locator(mdates.AutoDateLocator())
    ax1.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M'))

    if max(steps) > 10000:
        ax1.axhline(y=10000, color='#10b981', linestyle='--', alpha=0.7, 
                   label='목표: 10,000걸음')
    
    plt.tight_layout()
    img_buffer = BytesIO()
    plt.savefig(img_buffer, format='png', dpi=300, bbox_inches='tight')
    img_buffer.seek(0)
    plt.close()
    return img_buffer



def generate_gpt_analysis(data_text, prompt_type="general"):
    system_message = """
홀로 사는 노인 혹은 가족과 함께 사는 노인 등 전기 노인을 케어하는 애플리케이션 시스템입니다.
서비스의 목적은 노인의 건강한 생활 습관을 형성하고, 가족 및 의료진에게도 분석 정보를 공유하는 것입니다.
Fitbit 건강 데이터에 대한 전문적인 분석을 바탕으로, 습관 형성을 위한 동기부여와 격려를 제공하는 것이 목표입니다.

CAUTION
1. 잘못된 데이터나 정보를 포함하지 않았는지 반드시 점검하세요.
2. 모든 조언은 신뢰 가능한 문헌을 바탕으로 제공하세요.
3. 문헌 기반 분석은 하되, 출처는 사용자에게 보여주지 마세요.
4. 제공되지 않은 데이터에 대해 추측하거나 언급하지 마세요.
5. 응답의 논리와 표현은 처음부터 끝까지 일관성 있게 유지하세요.
6. 정상 범주를 벗어나는 수치는 반드시 명확하게 지적하세요.
7. 전문 용어는 일반인이 이해할 수 있게 쉽게 풀어 쓰세요.
8. 본문에 글자 수 정보는 포함하지 마세요.
9. 노인이 실천 가능한 수준이며 권장되는 활동만 제안하세요.
10. 가독성을 높이기 위해 분석 항목에는 이모지를 적절히 활용하세요.
11. 사용자를 부르는 호칭을 '어르신'으로 해주세요.
12. 가독성 좋게 들여쓰기와 줄바꿈을 해주세요.
13. 구체적인 수치를 분석에 포함하여 신뢰도를 높여주세요.
14. 60분을 넘어가는 시간의 경우에는 시간과 분 단위로 변환해주세요.

TONE
부드럽고 정중한 말투
""".strip()

    if prompt_type == "activity":
        user_prompt = f"""
운동 데이터를 기반으로 활동량과 운동 습관에 대한 분석을 제공해주세요. 수면 데이터는 언급하지 마세요. (300자 이내)
{data_text}
""".strip()
    elif prompt_type == "sleep":
        user_prompt = f"""
수면 데이터를 중심으로 수면 습관과 수면의 질에 대한 분석을 제공해주세요.
또한 수면 데이터를 토대로 수면 무호흡증, 불면증 등 의심되는 수면 질환이 있는지 알려주세요. 운동 데이터는 언급하지 마세요. (300자 이내)
{data_text}
""".strip()
    elif prompt_type == "overview":
        user_prompt = f"""
전체 데이터를 바탕으로 전반적인 건강 상태에 대한 전문적인 분석을 제공해주세요.
수면 데이터와 운동 데이터 사이에 연관성이나 상관관계가 있는지 분석해주세요.
데이터를 종합해 건강에 이상 신호가 있는지 여부를 판단하고 설명해주세요. (300자 이내)
{data_text}
""".strip()
    elif prompt_type == "help":
        user_prompt = f"""
어르신의 건강을 개선하기 위해 가족이 실천할 수 있는 행동과
의사가 권장할 수 있는 조치를 각각 반드시 제안해주세요. (300자 이내)
{data_text}
""".strip()
    else:
        user_prompt = data_text.strip()

    response = openai_client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": system_message},
            {"role": "user", "content": user_prompt}
        ],
        temperature=0.7
    )
    return response.choices[0].message.content

def format_analysis_data(user_data, fitbit_avg_data, qna_data):
    """새로운 테이블들의 데이터를 GPT 프롬프트용으로 포맷"""
    result = "[사용자 정보]\n"
    if user_data:
        user = user_data[0]
        result += f"이름: {user.get('username', 'N/A')}\n"
        result += f"생년월일: {user.get('birth_date', 'N/A')}\n"
        result += f"성별: {user.get('gender', 'N/A')}\n"
        result += f"신장: {user.get('height', 'N/A')}cm\n"
        result += f"체중: {user.get('weight', 'N/A')}kg\n"
        result += f"BMI: {user.get('BMI', 'N/A')}\n"
    
    result += "\n[일일 평균 건강 데이터]\n"
    if fitbit_avg_data:
        avg = fitbit_avg_data[0]
        result += f"평균 걸음수: {avg.get('avg_steps', 'N/A')}\n"
        result += f"평균 칼로리 소모: {avg.get('avg_calories_total', 'N/A')}\n"
        result += f"평균 이동 거리: {avg.get('avg_distance_km', 'N/A')} km\n"
        result += f"평균 심박수: {avg.get('avg_heart_rate', 'N/A')} bpm\n"
        result += f"평균 안정시 심박수: {avg.get('avg_resting_heart_rate', 'N/A')} bpm\n"
        result += f"평균 활동 시간: {avg.get('avg_activity_duration', 'N/A')} 분\n"
        result += f"평균 앉아있는 시간: {avg.get('avg_sedentary_minutes', 'N/A')} 분\n"
        result += f"평균 가벼운 활동 시간: {avg.get('avg_lightly_active_minutes', 'N/A')} 분\n"
        result += f"평균 보통 활동 시간: {avg.get('avg_fairly_active_minutes', 'N/A')} 분\n"
        result += f"평균 격렬한 활동 시간: {avg.get('avg_very_active_minutes', 'N/A')} 분\n"
        result += f"평균 총 수면 시간: {avg.get('avg_total_sleep_hours', 'N/A')} 시간\n"
        result += f"평균 깊은 수면: {avg.get('avg_deep_sleep_hours', 'N/A')} 시간\n"
        result += f"평균 얕은 수면: {avg.get('avg_light_sleep_hours', 'N/A')} 시간\n"
        result += f"평균 렘 수면: {avg.get('avg_rem_sleep_hours', 'N/A')} 시간\n"
        result += f"평균 깨어있는 시간: {avg.get('avg_awake_hours', 'N/A')} 시간\n"
        result += f"평균 HRV (심박변이도): {avg.get('avg_hrv', 'N/A')} ms\n"
        result += f"평균 RHR (안정시 심박수): {avg.get('avg_rhr', 'N/A')} bpm\n"
        result += f"평균 호흡수: {avg.get('avg_respiratory_rate', 'N/A')} 회/분\n"
        result += f"평균 피부 온도: {avg.get('avg_skin_temperature', 'N/A')} ℃\n"
        result += f"평균 스트레스 점수: {avg.get('avg_stress_score', 'N/A')}\n"
        result += f"평균 종합 점수: {avg.get('avg_total_score', 'N/A')}\n"
        result += f"평균 수면 점수: {avg.get('avg_sleep_score', 'N/A')}\n"

    result += "\n[설문조사 응답]\n"
    if qna_data:
        for qna in qna_data:
            result += f"질문: {qna.get('question', 'N/A')}\n"
            result += f"객관식 응답: {qna.get('multiple_choice_response', 'N/A')}\n"
            if qna.get('text_response'):
                result += f"주관식 응답: {qna.get('text_response')}\n"
            result += "\n"
    
    return result

# def insert_or_update_daily_report(user_id, report_date, exercise_analysis, sleep_analysis, overview_analysis, help_analysis):
#     """daily_health_reports 테이블에 분석 결과를 insert 또는 update"""
#     conn = pymysql.connect(
#         host=DB_HOST,
#         user=DB_USER,
#         password=DB_PASSWORD,
#         database=DB_NAME,
#         cursorclass=pymysql.cursors.DictCursor
#     )
#     try:
#         with conn.cursor() as cursor:
#             check_query = """
#             SELECT id FROM daily_health_reports 
#             WHERE user_id = %s AND report_date = %s
#             """
#             cursor.execute(check_query, (user_id, report_date))
#             existing_record = cursor.fetchone()
            
#             if existing_record:
#                 update_query = """
#                 UPDATE daily_health_reports 
#                 SET exercise_gpt_analysis = %s, sleep_gpt_analysis = %s, updated_at = NOW()
#                 WHERE user_id = %s AND report_date = %s
#                 """
#                 cursor.execute(update_query, (exercise_analysis, sleep_analysis, user_id, report_date))
#             else:
#                 insert_query = """
#                 INSERT INTO daily_health_reports (user_id, report_date, exercise_gpt_analysis, sleep_gpt_analysis, created_at, updated_at)
#                 VALUES (%s, %s, %s, %s, NOW(), NOW())
#                 """
#                 cursor.execute(insert_query, (user_id, report_date, exercise_analysis, sleep_analysis))
            
#             conn.commit()
#     finally:
#         conn.close()

def insert_or_update_daily_report(user_id, report_date, exercise_analysis, sleep_analysis, overview_analysis, help_analysis):
    """daily_health_reports 테이블에 분석 결과를 insert 또는 update"""
    conn = pymysql.connect(
        host=DB_HOST,
        user=DB_USER,
        password=DB_PASSWORD,
        database=DB_NAME,
        cursorclass=pymysql.cursors.DictCursor
    )
    try:
        with conn.cursor() as cursor:
            check_query = """
            SELECT id FROM daily_health_reports 
            WHERE user_id = %s AND report_date = %s
            """
            cursor.execute(check_query, (user_id, report_date))
            existing_record = cursor.fetchone()
            
            if existing_record:
                update_query = """
                UPDATE daily_health_reports 
                SET exercise_gpt_analysis = %s,
                    sleep_gpt_analysis = %s,
                    overview_gpt_analysis = %s,
                    help_gpt_analysis = %s,
                    updated_at = NOW()
                WHERE user_id = %s AND report_date = %s
                """
                cursor.execute(update_query, (
                    exercise_analysis,
                    sleep_analysis,
                    overview_analysis,
                    help_analysis,
                    user_id,
                    report_date
                ))
            else:
                insert_query = """
                INSERT INTO daily_health_reports (
                    user_id,
                    report_date,
                    exercise_gpt_analysis,
                    sleep_gpt_analysis,
                    overview_gpt_analysis,
                    help_gpt_analysis,
                    created_at,
                    updated_at
                )
                VALUES (%s, %s, %s, %s, %s, %s, NOW(), NOW())
                """
                cursor.execute(insert_query, (
                    user_id,
                    report_date,
                    exercise_analysis,
                    sleep_analysis,
                    overview_analysis,
                    help_analysis
                ))
            
            conn.commit()
    finally:
        conn.close()

def update_report_status(user_id, report_date, status='completed'):
    """daily_health_reports 테이블의 report_status를 업데이트"""
    conn = pymysql.connect(
        host=DB_HOST,
        user=DB_USER,
        password=DB_PASSWORD,
        database=DB_NAME,
        cursorclass=pymysql.cursors.DictCursor
    )
    try:
        with conn.cursor() as cursor:
            check_query = """
            SELECT id FROM daily_health_reports 
            WHERE user_id = %s AND report_date = %s
            """
            cursor.execute(check_query, (user_id, report_date))
            existing_record = cursor.fetchone()
            
            if existing_record:
                update_query = """
                UPDATE daily_health_reports 
                SET report_status = %s, updated_at = NOW()
                WHERE user_id = %s AND report_date = %s
                """
                cursor.execute(update_query, (status, user_id, report_date))
            else:
                insert_query = """
                INSERT INTO daily_health_reports (user_id, report_date, report_status, created_at, updated_at)
                VALUES (%s, %s, %s, NOW(), NOW())
                """
                cursor.execute(insert_query, (user_id, report_date, status))
            
            conn.commit()
    finally:
        conn.close()

def generate_pdf_report(activity_analysis, sleep_analysis, overview_analysis, help_analysis, img1, img2, img3, username, target_date):
    pdf = FPDF()
    pdf.add_page()
    pdf.add_font("Nanum", "", "/tmp/NanumGothic-Regular.ttf", uni=True)
    pdf.set_font("Nanum", size=12)
    
    # today_str = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')

    pdf.set_font("Nanum", size=20)
    pdf.set_text_color(33, 33, 33)
    # pdf.cell(0, 15, f"{username}님의 건강 리포트 - {today_str}", ln=True, align='C')
    pdf.cell(0, 15, f"{username}님의 건강 리포트 - {target_date}", ln=True, align='C')
    pdf.ln(5)

    pdf.set_font("Nanum", size=14)
    pdf.set_text_color(102, 0, 70)
    pdf.cell(0, 10, "전체 건강상태 분석", ln=True)
    pdf.set_draw_color(102, 0, 70)
    pdf.set_line_width(0.5)
    pdf.line(10, pdf.get_y(), 200, pdf.get_y())
    pdf.ln(3)
    pdf.set_font("Nanum", size=12)
    pdf.set_text_color(0, 0, 0)
    pdf.multi_cell(0, 8, wrap_text(overview_analysis, 80))
    pdf.ln(4)

    pdf.set_font("Nanum", size=14)
    pdf.set_text_color(0, 102, 204)
    pdf.cell(0, 10, "활동 분석", ln=True)
    pdf.set_draw_color(0, 102, 204)
    pdf.set_line_width(0.5)
    pdf.line(10, pdf.get_y(), 200, pdf.get_y())
    pdf.ln(3)
    pdf.set_font("Nanum", size=12)
    pdf.set_text_color(0, 0, 0)
    pdf.multi_cell(0, 8, wrap_text(activity_analysis, 80))
    pdf.ln(4)

    pdf.image(img1, x=15, w=180)
    pdf.ln(5)
    pdf.image(img2, x=15, w=180)
    pdf.ln(10)

    pdf.set_font("Nanum", size=14)
    pdf.set_text_color(102, 0, 153)
    pdf.cell(0, 10, "수면 분석", ln=True)
    pdf.set_draw_color(102, 0, 153)
    pdf.set_line_width(0.5)
    pdf.line(10, pdf.get_y(), 200, pdf.get_y())
    pdf.ln(3)
    pdf.set_font("Nanum", size=12)
    pdf.set_text_color(0, 0, 0)
    pdf.multi_cell(0, 8, wrap_text(sleep_analysis, 80))
    pdf.ln(4)
    pdf.image(img3, x=15, w=180)

    pdf.set_font("Nanum", size=14)
    pdf.set_text_color(102, 0, 110)
    pdf.cell(0, 10, "보호자 및 의사를 위한 어르신을 도와드릴 수 있는 방법", ln=True)
    pdf.set_draw_color(102, 0, 110)
    pdf.set_line_width(0.5)
    pdf.line(10, pdf.get_y(), 200, pdf.get_y())
    pdf.ln(3)
    pdf.set_font("Nanum", size=12)
    pdf.set_text_color(0, 0, 0)
    pdf.multi_cell(0, 8, wrap_text(help_analysis, 80))
    pdf.ln(4)

    output_buffer = BytesIO()
    pdf.output(output_buffer)
    output_buffer.seek(0)
    return output_buffer

def download_font_from_s3(bucket, key, local_path="/tmp/NanumGothic-Regular.ttf"):
    boto3.client("s3").download_file(bucket, key, local_path)

# (수정 코드 확정 후 삭제!)
# def lambda_handler(event, context):
#     matplotlib.rcParams['font.family'] = 'NanumGothic'
#     matplotlib.rcParams['axes.unicode_minus'] = False
#     download_font_from_s3(S3_BUCKET_PDF, "fonts/NanumGothic-Regular.ttf")
    
#     today = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')
#     # today = (datetime.now()).strftime('%Y-%m-%d')
    
#     conn = pymysql.connect(
#         host=DB_HOST,
#         user=DB_USER,
#         password=DB_PASSWORD,
#         database=DB_NAME,
#         cursorclass=pymysql.cursors.DictCursor
#     )

#     try:
#         with conn.cursor() as cursor:
#             cursor.execute("SELECT id, username, encodedId FROM users WHERE role = 'senior'")
#             seniors = cursor.fetchall()
        
#         for senior in seniors:
#             user_id = senior['id']
#             username = senior['username']
#             encoded_id = senior['encodedId']

#             sleep_data_raw = fetch_fitbit_data(f"SELECT * FROM fitbit_sleep_data WHERE user_id = {user_id} AND date = '{today}'")
#             activity_data_raw = fetch_fitbit_data(f"SELECT * FROM fitbit_activity_data WHERE user_id = {user_id} AND DATE(date) = '{today}'")
            
#             if not sleep_data_raw or not activity_data_raw:
#                 continue
            
#             sleep_data = prepare_sleep_data(sleep_data_raw)
#             activity_data = prepare_activity_data(activity_data_raw)
            
#             sleep_graph = generate_sleep_step_graph_week(sleep_data)
#             hr_graph = generate_heart_rate(activity_data)
#             step_graph = generate_step_and_calories_graph(activity_data)
            
#             upload_to_s3(sleep_graph, f"graphs/{today}_{username}_sleep.png", S3_BUCKET_GRAPH)
#             upload_to_s3(hr_graph, f"graphs/{today}_{username}_heartrate.png", S3_BUCKET_GRAPH)
#             upload_to_s3(step_graph, f"graphs/{today}_{username}_steps_calories.png", S3_BUCKET_GRAPH)
            
#             user_data = fetch_fitbit_data(f"SELECT * FROM users WHERE id = {user_id}")
            
#             fitbit_avg_data = fetch_fitbit_data(f"""
#                 SELECT * FROM fitbit_average 
#                 WHERE user_id = {user_id} AND date = '{today}' AND period_type = '1D'
#             """)
            
#             qna_data = fetch_fitbit_data(f"""
#                 SELECT question, multiple_choice_response, text_response 
#                 FROM qna_info 
#                 WHERE user_id = {user_id} AND date = '{today}'
#             """)
            
#             analysis_prompt = format_analysis_data(user_data, fitbit_avg_data, qna_data)
            
#             gpt_results = {}
#             for prompt_type in ['activity', 'sleep', 'overview', 'help']:
#                 raw_result = generate_gpt_analysis(analysis_prompt, prompt_type)
#                 cleaned = wrap_text(remove_unsupported_chars(raw_result))
#                 gpt_results[prompt_type] = cleaned
            
#             insert_or_update_daily_report(
#                 user_id, 
#                 today, 
#                 gpt_results['activity'], 
#                 gpt_results['sleep']
#             )
            
#             pdf_buffer = generate_pdf_report(
#                 gpt_results['activity'],
#                 gpt_results['sleep'],
#                 gpt_results['overview'],
#                 gpt_results['help'],
#                 hr_graph,
#                 step_graph,
#                 sleep_graph,
#                 username
#             )
            
#             upload_result = upload_pdf_to_s3(pdf_buffer, username, today)

#             if upload_result:
#                 s3 = boto3.client('s3')
#                 pdf_key = f"healthreport/건강리포트_{today}_{username}.pdf"
#                 try:
#                     s3.head_object(Bucket=S3_BUCKET_PDF, Key=pdf_key)
#                     print(f"PDF 확인됨: {pdf_key}")

#                     update_report_status(user_id, today, 'completed')
#                     print(f"리포트 상태 'completed'로 변경 완료. {user_id} 님의 {today} 리포트")
                    
#                     invoke_alarm_lambda(encoded_id)
#                     invoke_fd_alarm_lambda(encoded_id)
#                 except s3.exceptions.ClientError as e:
#                     print(f"S3에서 PDF 존재하지 않음: {e}")
#             else:
#                 print(f"PDF 리포트가 없습니다: {username}, {today}")

#     finally:
#         conn.close()
    
#     return {
#         "statusCode": 200,
#         "body": {
#             "message": "PDF 리포트 생성 및 업로드 완료."
#         }
#     }

def lambda_handler(event, context):
    matplotlib.rcParams['font.family'] = 'NanumGothic'
    matplotlib.rcParams['axes.unicode_minus'] = False
    download_font_from_s3(S3_BUCKET_PDF, "fonts/NanumGothic-Regular.ttf")
    
    user_id = event['detail']['userId']
    target_date = event['detail']['date']
    
    conn = pymysql.connect(
        host=DB_HOST,
        user=DB_USER,
        password=DB_PASSWORD,
        database=DB_NAME,
        cursorclass=pymysql.cursors.DictCursor
    )
    
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT id, username, encodedId FROM users WHERE id = %s AND role = 'senior'", (user_id,))
            senior = cursor.fetchone()
            
            if not senior:
                return {
                    "statusCode": 404,
                    "body": {"message": f"Senior user not found: {user_id}"}
                }
        
        username = senior['username']
        encoded_id = senior['encodedId']

        sleep_data_raw = fetch_fitbit_data(f"SELECT * FROM fitbit_sleep_data WHERE user_id = {user_id} AND date = '{target_date}'")
        activity_data_raw = fetch_fitbit_data(f"SELECT * FROM fitbit_activity_data WHERE user_id = {user_id} AND DATE(date) = '{target_date}'")
        
        if not sleep_data_raw or not activity_data_raw:
            return {
                "statusCode": 404,
                "body": {"message": f"No data found for user {user_id} on {target_date}"}
            }
        
        sleep_data = prepare_sleep_data(sleep_data_raw)
        activity_data = prepare_activity_data(activity_data_raw)
        
        sleep_graph = generate_sleep_step_graph_week(sleep_data)
        hr_graph = generate_heart_rate(activity_data)
        step_graph = generate_step_and_calories_graph(activity_data)
        
        upload_to_s3(sleep_graph, f"graphs/{target_date}_{username}_sleep.png", S3_BUCKET_GRAPH)
        upload_to_s3(hr_graph, f"graphs/{target_date}_{username}_heartrate.png", S3_BUCKET_GRAPH)
        upload_to_s3(step_graph, f"graphs/{target_date}_{username}_steps_calories.png", S3_BUCKET_GRAPH)
        
        user_data = fetch_fitbit_data(f"SELECT * FROM users WHERE id = {user_id}")
        
        fitbit_avg_data = fetch_fitbit_data(f"""
            SELECT * FROM fitbit_average 
            WHERE user_id = {user_id} AND date = '{target_date}' AND period_type = '1D'
        """)
        
        qna_data = fetch_fitbit_data(f"""
            SELECT question, multiple_choice_response, text_response 
            FROM qna_info 
            WHERE user_id = {user_id} AND date = '{target_date}'
        """)
        
        analysis_prompt = format_analysis_data(user_data, fitbit_avg_data, qna_data)
        
        gpt_results = {}
        for prompt_type in ['activity', 'sleep', 'overview', 'help']:
            raw_result = generate_gpt_analysis(analysis_prompt, prompt_type)
            cleaned = wrap_text(remove_unsupported_chars(raw_result))
            gpt_results[prompt_type] = cleaned
        
        insert_or_update_daily_report(
            user_id, 
            target_date, 
            gpt_results['activity'], 
            gpt_results['sleep'],
            gpt_results['overview'],
            gpt_results['help']
        )
        
        pdf_buffer = generate_pdf_report(
            gpt_results['activity'],
            gpt_results['sleep'],
            gpt_results['overview'],
            gpt_results['help'],
            hr_graph,
            step_graph,
            sleep_graph,
            username,
            target_date
        )
        
        upload_result = upload_pdf_to_s3(pdf_buffer, username, target_date)

        if upload_result:
            s3 = boto3.client('s3')
            pdf_key = f"healthreport/건강리포트_{target_date}_{username}.pdf"
            try:
                s3.head_object(Bucket=S3_BUCKET_PDF, Key=pdf_key)
                print(f"PDF 확인됨: {pdf_key}")

                update_report_status(user_id, target_date, 'completed')
                print(f"리포트 상태 'completed'로 변경 완료. {user_id} 님의 {target_date} 리포트")
                
                with conn.cursor() as cursor:
                    cursor.execute(
                        "SELECT id FROM daily_missions WHERE user_id = %s AND date = %s", 
                        (user_id, target_date)
                    )
                    existing_mission = cursor.fetchone()
                    
                    if not existing_mission:
                        cursor.execute(
                            "INSERT INTO daily_missions (user_id, date, mission_quiz, mission_report, mission_exercise, mission_sleep, completed_count, marker_type) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)", 
                            (user_id, target_date, False, False, False, False, 0, 'seed')
                        )
                        conn.commit()
                        print(f"Daily mission record created for user {user_id} on {target_date}")
                    else:
                        print(f"Daily mission record already exists for user {user_id} on {target_date}")

                invoke_alarm_lambda(encoded_id)
                invoke_fd_alarm_lambda(encoded_id)
            except s3.exceptions.ClientError as e:
                print(f"S3에서 PDF 존재하지 않음: {e}")
                return {
                    "statusCode": 500,
                    "body": {"message": f"PDF upload failed for user {user_id}"}
                }
        else:
            print(f"PDF 리포트가 없습니다: {username}, {target_date}")
            return {
                "statusCode": 500,
                "body": {"message": f"PDF generation failed: {username}, {target_date}"}
            }

    finally:
        conn.close()
    
    return {
        "statusCode": 200,
        "body": {
            "message": f"PDF 리포트 생성 및 업로드 완료. User: {user_id}, Date: {target_date}"
        }
    }