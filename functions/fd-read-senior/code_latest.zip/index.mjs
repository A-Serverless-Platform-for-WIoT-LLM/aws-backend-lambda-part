import mysql from 'mysql2/promise';

export const handler = async event => {
  let connection;

  try {
    const encodedId = event.queryStringParameters?.encodedId;

    if (!encodedId) {
      return buildResponse(400, {
        error: 'Missing required query parameter: encodedId',
      });
    }

    connection = await createDbConnection();

    const [rows] = await connection.execute(
      `SELECT username, birth_date, gender, address, phone_number, height, weight,
              profile_image_url, profile_image_key, breakfast_time, lunch_time, dinner_time,
              guardian_code, doctor_code
         FROM users
        WHERE encodedId = ?`,
      [encodedId]
    );

    if (rows.length === 0) {
      return buildResponse(404, { error: 'User not found' });
    }

    return buildResponse(200, rows[0]);
  } catch (error) {
    console.error('Lambda error:', error);
    return buildResponse(500, {
      error: 'Internal Server Error',
      detail: error.message,
    });
  } finally {
    if (connection) await connection.end();
  }
};

async function createDbConnection() {
  return await mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    charset: 'utf8mb4',
  });
}

function buildResponse(statusCode, body) {
  return {
    statusCode,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
    },
    body: JSON.stringify(body),
  };
}
