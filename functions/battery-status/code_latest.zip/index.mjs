import mysql from 'mysql2/promise';

export const handler = async (event) => {
  let connection;

  try {
    const { encodedId } = JSON.parse(event.body);
    if (!encodedId) {
      return buildResponse(400, { error: 'Missing encodedId' });
    }

    connection = await mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
      charset: 'utf8mb4',
    });

    const [[user]] = await connection.execute(
      'SELECT id FROM users WHERE encodedId = ?',
      [encodedId]
    );
    if (!user) return buildResponse(404, { error: 'User not found' });

    const [[device]] = await connection.execute(
      'SELECT device_version, battery_level, last_sync_time FROM fitbit_device WHERE user_id = ? ORDER BY updated_at DESC LIMIT 1',
      [user.id]
    );
    if (!device) return buildResponse(404, { error: 'No device data' });

    return buildResponse(200, device);
  } catch (err) {
    console.error('Lambda error:', err);
    return buildResponse(500, { error: 'Internal Server Error', detail: err.message });
  } finally {
    if (connection) await connection.end();
  }
};

function buildResponse(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  };
}
