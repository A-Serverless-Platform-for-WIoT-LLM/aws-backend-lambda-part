import mysql from 'mysql2/promise';

export const handler = async (event) => {
  let connection;
  try {
    console.log("Received event:", JSON.stringify(event));

    const encodedId = event.queryStringParameters?.encodedId;
    console.log("encodedId:", encodedId);

    if (!encodedId) {
      return buildResponse(400, { error: 'Missing encodedId' });
    }

    connection = await mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
      charset: 'utf8mb4',
    });

    console.log("Connected to DB");

    const [rows] = await connection.execute(
      `SELECT username, height, weight, birth_date, gender 
       FROM users 
       WHERE encodedId = ?`,
      [encodedId]
    );

    console.log("User query result:", rows);

    if (rows.length === 0) {
      return buildResponse(404, { error: 'User not found' });
    }

    const user = rows[0];
    console.log("Fetched user:", user);

    const requiredFields = ['username', 'height', 'weight', 'birth_date', 'gender'];
    const missingFields = requiredFields.filter(field => user[field] === null || user[field] === '');

    console.log("Missing fields:", missingFields);

    return buildResponse(200, {
      allEntered: missingFields.length === 0,
      missingFields,
    });

  } catch (error) {
    console.error('Lambda error:', error);
    return buildResponse(500, { error: 'Internal Server Error', message: error.message });
  } finally {
    if (connection) {
      console.log("Closing DB connection");
      await connection.end();
    }
  }
};

function buildResponse(statusCode, body) {
  return {
    statusCode,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Access-Control-Allow-Origin': '*',
    },
    body: JSON.stringify(body),
  };
}
