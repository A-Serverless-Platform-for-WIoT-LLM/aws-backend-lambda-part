import mysql from 'mysql2/promise';

export const handler = async (event) => {
  let connection;

  try {
    const { encodedId, date } = JSON.parse(event.body);
    if (!encodedId || !date) {
      return buildResponse(400, { error: 'Missing required fields' });
    }

    connection = await mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
      charset: 'utf8mb4',
    });

    const [[user]] = await connection.execute(
      'SELECT id FROM users WHERE encodedId = ?',
      [encodedId]
    );
    if (!user) return buildResponse(404, { error: 'User not found' });

    const [[result]] = await connection.execute(
      `SELECT gpt_qna_analysis FROM qna_info WHERE user_id = ? AND date = ? LIMIT 1`,
      [user.id, date]
    );

    if (!result) {
      return buildResponse(200, { gpt_analysis: null });
    }

    return buildResponse(200, { gpt_analysis: result.gpt_qna_analysis });
  } catch (err) {
    console.error('Lambda error:', err);
    return buildResponse(500, { error: 'Internal Server Error', detail: err.message });
  } finally {
    if (connection) await connection.end();
  }
};

function buildResponse(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json; charset=utf-8' },
    body: JSON.stringify(body),
  };
}
